"use client";

import { useEffect, useRef, useState, useMemo } from "react";
import { useSession, signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { SPHERE_INIT_RX, SPHERE_INIT_RY } from "@/lib/sphereConfig";
import { PlaylistButton } from "@/components/PlaylistButton";
import LiveEventsIcon from "@/components/LiveEventsIcon";

// ── Short display labels ───────────────────────────────────────────────────────

const GENRE_SHORT: Record<string, string> = {
  "Jazz / Blues":                   "Jazz",
  "Rap / Hip-Hop":                  "Rap",
  "R&B / Soul / Funk":              "R&B",
  "Classical / Score / Soundtrack": "Classical",
  "Pop / Dance":                    "Pop",
  "Rock / Indie / Alternative":     "Rock",
  "Electronic / Ambient":           "Electronic",
  "World / Folk / Regional":        "World",
};
const shortLabel = (g: string) => GENRE_SHORT[g] ?? g;

// ── Palette ───────────────────────────────────────────────────────────────────

const COLORS: Record<string, string> = {
  "Rap / Hip-Hop":                  "#a78bfa",
  "R&B / Soul / Funk":              "#fb923c",
  "Rock / Indie / Alternative":     "#f87171",
  "Pop / Dance":                    "#f472b6",
  "Jazz / Blues":                   "#60a5fa",
  "Electronic / Ambient":           "#22d3ee",
  "Classical / Score / Soundtrack": "#fbbf24",
  "World / Folk / Regional":        "#4ade80",
  "Other":                          "#71717a",
};

// ── Types ─────────────────────────────────────────────────────────────────────

type TrackItem = {
  id: string; name: string; artist: string;
  album: string | null;
  imageUrl?: string | null; previewUrl?: string | null; spotifyId?: string | null;
  blueprintSubgenre: string;
  socialCount?: number;
  socialUsers?: { id: string; name: string | null }[];
  // Attached at render-time when Live Events mode is active
  liveEvent?: LiveEvent;
  // Set by API when ?unheardForUserId is present.
  // true  = track not in substitute user's library (unheard)
  // false = track IS in substitute user's library (heard)
  // undefined = no spotifyId or no substitute selected
  isUnheardForSelectedUser?: boolean;
};
type SubgenreItem = { name: string; count: number };
type LiveEvent = {
  artistName: string;
  eventName:  string;
  city:       string;
  venue:      string;
  date:       string;   // "YYYY-MM-DD"
  url:        string;
};
type V3  = [number, number, number];
type Tri = [number, number, number];
type Geometry = {
  verts:   V3[];
  faces:   Tri[];
  cents:   V3[];
  adj:     number[][];
  names:   string[];
  region:  number[];
  rgbMap:  [number, number, number][];
};

// ── Arcball math (identical to homepage) ──────────────────────────────────────

function matFromEuler(rx: number, ry: number): number[] {
  const cX = Math.cos(rx), sX = Math.sin(rx);
  const cY = Math.cos(ry), sY = Math.sin(ry);
  return [cY, 0, sY, sX*sY, cX, -sX*cY, -cX*sY, sX, cX*cY];
}

function arcballVec(px: number, py: number, cx: number, cy: number, r: number): V3 {
  const nx = (px - cx) / r, ny = (py - cy) / r;
  const d2 = nx * nx + ny * ny;
  if (d2 <= 0.5) return [nx, ny, Math.sqrt(1 - d2)];
  const z = 0.5 / Math.sqrt(d2), len = Math.sqrt(d2 + z * z);
  return [nx / len, ny / len, z / len];
}

function quatFromTo(a: V3, b: V3): [number, number, number, number] {
  const cx = a[1]*b[2]-a[2]*b[1], cy = a[2]*b[0]-a[0]*b[2], cz = a[0]*b[1]-a[1]*b[0];
  const w  = 1 + a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
  const len = Math.sqrt(w*w+cx*cx+cy*cy+cz*cz);
  if (len < 1e-10) return [1,0,0,0];
  return [w/len, cx/len, cy/len, cz/len];
}

function matFromQuat([w, x, y, z]: [number, number, number, number]): number[] {
  return [
    1-2*(y*y+z*z), 2*(x*y-w*z),   2*(x*z+w*y),
    2*(x*y+w*z),   1-2*(x*x+z*z), 2*(y*z-w*x),
    2*(x*z-w*y),   2*(y*z+w*x),   1-2*(x*x+y*y),
  ];
}

function mat3Premul(d: number[], c: number[]): number[] {
  return [
    d[0]*c[0]+d[1]*c[3]+d[2]*c[6], d[0]*c[1]+d[1]*c[4]+d[2]*c[7], d[0]*c[2]+d[1]*c[5]+d[2]*c[8],
    d[3]*c[0]+d[4]*c[3]+d[5]*c[6], d[3]*c[1]+d[4]*c[4]+d[5]*c[7], d[3]*c[2]+d[4]*c[5]+d[5]*c[8],
    d[6]*c[0]+d[7]*c[3]+d[8]*c[6], d[6]*c[1]+d[7]*c[4]+d[8]*c[7], d[6]*c[2]+d[7]*c[5]+d[8]*c[8],
  ];
}

function mat3Ortho(m: number[]): number[] {
  let [a0,a1,a2, b0,b1,b2] = m;
  let n = Math.sqrt(a0*a0+a1*a1+a2*a2); a0/=n; a1/=n; a2/=n;
  const dot = b0*a0+b1*a1+b2*a2; b0-=dot*a0; b1-=dot*a1; b2-=dot*a2;
  n = Math.sqrt(b0*b0+b1*b1+b2*b2); b0/=n; b1/=n; b2/=n;
  return [a0,a1,a2, b0,b1,b2, a1*b2-a2*b1, a2*b0-a0*b2, a0*b1-a1*b0];
}

// ── Geometry helpers ──────────────────────────────────────────────────────────

const norm3 = ([x,y,z]: V3): V3 => { const l=Math.sqrt(x*x+y*y+z*z); return [x/l,y/l,z/l]; };

function buildIcosphere(s: number): { verts: V3[]; faces: Tri[] } {
  const φ = (1+Math.sqrt(5))/2;
  let verts: V3[] = ([[-1,φ,0],[1,φ,0],[-1,-φ,0],[1,-φ,0],[0,-1,φ],[0,1,φ],[0,-1,-φ],[0,1,-φ],[φ,0,-1],[φ,0,1],[-φ,0,-1],[-φ,0,1]] as V3[]).map(norm3);
  let faces: Tri[] = [[0,11,5],[0,5,1],[0,1,7],[0,7,10],[0,10,11],[1,5,9],[5,11,4],[11,10,2],[10,7,6],[7,1,8],[3,9,4],[3,4,2],[3,2,6],[3,6,8],[3,8,9],[4,9,5],[2,4,11],[6,2,10],[8,6,7],[9,8,1]];
  for (let i=0;i<s;i++) {
    const cache = new Map<string,number>();
    const mid = (a:number,b:number) => { const k=a<b?`${a}:${b}`:`${b}:${a}`; if(cache.has(k))return cache.get(k)!; const[ax,ay,az]=verts[a],[bx,by,bz]=verts[b]; verts.push(norm3([(ax+bx)/2,(ay+by)/2,(az+bz)/2])); cache.set(k,verts.length-1); return verts.length-1; };
    const next: Tri[] = [];
    for (const [a,b,c] of faces) { const ab=mid(a,b),bc=mid(b,c),ca=mid(c,a); next.push([a,ab,ca],[b,bc,ab],[c,ca,bc],[ab,bc,ca]); }
    faces = next;
  }
  return { verts, faces };
}

function fiboPoles(n: number): V3[] {
  const phi = Math.PI*(3-Math.sqrt(5));
  return Array.from({length:n},(_,i)=>{const y=n>1?1-(i/(n-1))*2:0,r=Math.sqrt(Math.max(0,1-y*y)),t=phi*i;return[Math.cos(t)*r,y,Math.sin(t)*r] as V3;});
}

function triCentroid(verts: V3[], [a,b,c]: Tri): V3 {
  return norm3([(verts[a][0]+verts[b][0]+verts[c][0])/3,(verts[a][1]+verts[b][1]+verts[c][1])/3,(verts[a][2]+verts[b][2]+verts[c][2])/3]);
}

function assignVoronoi(cents: V3[], poles: V3[], bonuses: number[]): number[] {
  return cents.map(c => { let best=0,bs=Infinity; for(let i=0;i<poles.length;i++){const cos=Math.min(1,Math.max(-1,c[0]*poles[i][0]+c[1]*poles[i][1]+c[2]*poles[i][2]));const s=Math.acos(cos)-bonuses[i];if(s<bs){bs=s;best=i;}} return best; });
}

function lloydRelax(cents: V3[], p0: V3[], bonuses: number[], iters: number): {poles:V3[];region:number[]} {
  let poles=p0.map(p=>[...p] as V3), region=assignVoronoi(cents,poles,bonuses);
  for (let t=0;t<iters;t++) {
    const sum: V3[]=poles.map(()=>[0,0,0] as V3); const cnt=new Int32Array(poles.length);
    for(let fi=0;fi<cents.length;fi++){const ri=region[fi];sum[ri][0]+=cents[fi][0];sum[ri][1]+=cents[fi][1];sum[ri][2]+=cents[fi][2];cnt[ri]++;}
    for(let i=0;i<poles.length;i++){if(cnt[i]>0)poles[i]=norm3([sum[i][0]/cnt[i],sum[i][1]/cnt[i],sum[i][2]/cnt[i]]);}
    region=assignVoronoi(cents,poles,bonuses);
  }
  return {poles,region};
}

function buildAdjacency(faces: Tri[]): number[][] {
  const em=new Map<string,number[]>();
  for(let fi=0;fi<faces.length;fi++){const[a,b,c]=faces[fi];for(const[p,q] of[[a,b],[b,c],[c,a]] as [number,number][]){const k=p<q?`${p}:${q}`:`${q}:${p}`;if(!em.has(k))em.set(k,[]);em.get(k)!.push(fi);}}
  const adj: number[][]=Array.from({length:faces.length},()=>[]);
  for(const[,fl] of em){if(fl.length===2){adj[fl[0]].push(fl[1]);adj[fl[1]].push(fl[0]);}}
  return adj;
}

function removeIslands(region: number[], adj: number[][], ng: number): number[] {
  const result=[...region];
  for(let g=0;g<ng;g++){
    const members: number[]=[];
    for(let fi=0;fi<result.length;fi++){if(result[fi]===g)members.push(fi);}
    if(!members.length)continue;
    const visited=new Set<number>(), components: number[][]=[];
    for(const seed of members){if(visited.has(seed))continue;const comp: number[]=[],queue=[seed];visited.add(seed);while(queue.length){const fi=queue.shift()!;comp.push(fi);for(const ni of adj[fi]){if(!visited.has(ni)&&result[ni]===g){visited.add(ni);queue.push(ni);}}}components.push(comp);}
    if(components.length<=1)continue;
    const largest=components.reduce((a,b)=>b.length>a.length?b:a);
    for(const comp of components){if(comp===largest)continue;for(const fi of comp){const votes=new Map<number,number>();for(const ni of adj[fi]){const ng2=result[ni];if(ng2!==g)votes.set(ng2,(votes.get(ng2)??0)+1);}let winner=-1,top=0;for(const[ng2,v] of votes){if(v>top){top=v;winner=ng2;}}if(winner>=0)result[fi]=winner;}}
  }
  return result;
}

function hexRgb(h: string): [number, number, number] {
  return [parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)];
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Normalizes artist name the same way the API does — used as the liveEventMap key. */
const normalizeArtist = (name: string) =>
  name.toLowerCase().trim().replace(/\s+/g, " ");



// ── SpotifyLogoButton ─────────────────────────────────────────────────────────

function SpotifyLogoButton({ track, size=26 }: { track:{name:string;spotifyId?:string|null}|null; size?:number }) {
  const active=!!track, canOpen=!!(track?.spotifyId);
  const handleClick=(e: React.MouseEvent)=>{
    e.stopPropagation(); if(!canOpen||!track?.spotifyId)return;
    const url=`https://open.spotify.com/track/${track.spotifyId}`;
    if(window.confirm(`Open "${track.name}" on Spotify?`))window.open(url,"_blank","noopener,noreferrer");
  };
  return (
    <button onClick={handleClick} aria-label={canOpen?`Open ${track?.name} on Spotify`:"Spotify"}
      style={{flexShrink:0,background:"none",border:"none",padding:0,cursor:canOpen?"pointer":"default",color:active?"#1DB954":"rgba(255,255,255,0.20)",transition:"color 0.25s ease",display:"flex",alignItems:"center",lineHeight:1}}>
      <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
        <path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z" />
      </svg>
    </button>
  );
}

// ── BarChartButton ────────────────────────────────────────────────────────────

function BarChartButton({ active, onClick, color }: { active: boolean; onClick: () => void; color: string }) {
  return (
    <button
      onClick={e => { e.stopPropagation(); onClick(); }}
      aria-label={active ? "Clear social sort" : "Sort by social popularity"}
      title={active ? "Sorted by how many Friends users share this track" : "Sort by Friends popularity"}
      style={{
        flexShrink:  0,
        background:  "none",
        border:      "none",
        padding:     "2px",
        cursor:      "pointer",
        color:       active ? color : "rgba(255,255,255,0.22)",
        transition:  "color 0.20s ease",
        display:     "flex",
        alignItems:  "center",
        lineHeight:  1,
      }}
    >
      {/* Three ascending bars */}
      <svg width={19} height={17} viewBox="0 0 12 10" fill="currentColor" aria-hidden="true">
        <rect x="0"   y="5.5" width="2.8" height="4.5" rx="0.5"/>
        <rect x="4.6" y="2.5" width="2.8" height="7.5" rx="0.5"/>
        <rect x="9.2" y="0"   width="2.8" height="10"  rx="0.5"/>
      </svg>
    </button>
  );
}

// ── PinButton — live-events mode toggle ───────────────────────────────────────

function PinButton({
  active, loading, onClick, color,
}: {
  active:  boolean;
  loading: boolean;
  onClick: () => void;
  color:   string;
}) {
  return (
    <button
      onClick={e => { e.stopPropagation(); onClick(); }}
      aria-label={active ? "Hide live events" : "Find live events in California"}
      title={loading
        ? "Searching for CA live events…"
        : active
          ? "Live events mode on — click to turn off"
          : "Find upcoming CA live events for these artists"}
      disabled={loading}
      style={{
        flexShrink: 0,
        background: "none",
        border:     "none",
        padding:    "2px",
        cursor:     loading ? "default" : "pointer",
        color:      active ? color : "rgba(255,255,255,0.22)",
        opacity:    loading ? 0.55 : 1,
        transition: "color 0.20s ease, opacity 0.20s ease",
        display:    "flex",
        alignItems: "center",
        lineHeight: 1,
      }}
    >
      {loading ? (
        /* Three animated dots while searching */
        <svg width={19} height={17} viewBox="0 0 18 10" aria-hidden="true">
          {[0, 6, 12].map((cx, i) => (
            <circle key={i} cx={cx + 3} cy="5" r="1.6" fill="currentColor">
              <animate attributeName="opacity" values="0.25;1;0.25"
                dur="1.1s" repeatCount="indefinite" begin={`${i * 0.22}s`} />
            </circle>
          ))}
        </svg>
      ) : (
        <LiveEventsIcon size={17} />
      )}
    </button>
  );
}

// ── VennButton — opens the current genre/subgenre in Friends World ────────────
// Only rendered on individual user worlds (not on friendsWorld itself).
// When disabled (genre/subgenre absent from Friends World) renders as a muted
// non-interactive span instead of a navigable link.
// Icon: Users / group silhouette — visually distinct from UnheardButton's sparkle.

function VennButton({
  href,
  color,
  disabled = false,
  onBeforeNavigate,
}: {
  href:               string;
  color:              string;
  disabled?:          boolean;
  /** Called synchronously before the Link navigates — use to write sessionStorage. */
  onBeforeNavigate?:  () => void;
}) {
  // Users (two-person silhouette) — clearly communicates "Friends / group / network".
  // Deliberately different from the sparkle icon used by UnheardButton.
  const usersIcon = (
    <svg
      width={18} height={18} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth={2}
      strokeLinecap="round" strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );

  if (disabled) {
    return (
      <span
        aria-label="Not in Friends World"
        title="Not in Friends World"
        style={{
          flexShrink: 0,
          display:    "flex",
          alignItems: "center",
          lineHeight: 1,
          color:      "rgba(255,255,255,0.18)",
          cursor:     "default",
        }}
      >
        {usersIcon}
      </span>
    );
  }

  return (
    <Link
      href={href}
      onClick={e => {
        e.stopPropagation();
        onBeforeNavigate?.();
      }}
      aria-label="Open in Friends World"
      title="Open in Friends World"
      style={{
        flexShrink:     0,
        display:        "flex",
        alignItems:     "center",
        color,
        lineHeight:     1,
        textDecoration: "none",
        transition:     "color 0.20s ease",
      }}
    >
      {usersIcon}
    </Link>
  );
}

// ── UnheardButton — sort unheard tracks to top ───────────────────────────────
// Only rendered when a substitute profile is selected. Uses a sparkle icon to
// convey "undiscovered". Visually distinct from VennButton (which uses Users icon).

function UnheardButton({
  active,
  onClick,
  color,
  name,
}: {
  active:   boolean;
  onClick:  () => void;
  color:    string;
  /** Display name of the viewing-as profile — used in tooltip. */
  name?:    string;
}) {
  const label  = name ? `Show songs ${name} hasn't saved` : "Show unheard tracks first";
  const active_label = name ? `Showing songs ${name} hasn't saved` : "Showing unheard tracks first";
  return (
    <button
      type="button"
      onClick={e => { e.stopPropagation(); onClick(); }}
      aria-label={active ? "Disable unheard filter" : label}
      title={active ? active_label : label}
      style={{
        flexShrink: 0,
        background: "none",
        border:     "none",
        padding:    "2px",
        cursor:     "pointer",
        color:      active ? color : "rgba(255,255,255,0.28)",
        transition: "color 0.20s ease",
        display:    "flex",
        alignItems: "center",
        lineHeight: 1,
      }}
    >
      {/* Sparkle / asterisk — "new / undiscovered". Distinct from the Users icon on VennButton. */}
      <svg
        width={18} height={18} viewBox="0 0 24 24" fill="none"
        stroke="currentColor" strokeWidth={2}
        strokeLinecap="round" strokeLinejoin="round"
        aria-hidden="true"
      >
        <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z" />
      </svg>
    </button>
  );
}

// ── Social badge ──────────────────────────────────────────────────────────────
// Plain numeric count styled in the genre color. Always equals socialUsers.length.

function SocialBadge({ count, color }: { count: number; color: string }) {
  if (count <= 0) return null;
  return (
    <span
      aria-hidden="true"
      style={{
        fontSize:   11,
        fontWeight: 600,
        fontVariantNumeric: "tabular-nums",
        color,
        opacity:    0.72,
        lineHeight: 1,
        flexShrink: 0,
        userSelect: "none",
      }}
    >
      {count}
    </span>
  );
}

// ── Component ─────────────────────────────────────────────────────────────────

interface WorldSphereProps {
  /** If set, load data for this specific user instead of the session user. */
  userId?: string;
  /** If set, show a back-navigation button pointing at this href (e.g. "/midvale"). */
  backHref?: string;
  /**
   * Display name for the mobile headline ("Chris's Music" / "Chris' Music").
   * When omitted the headline is suppressed.
   */
  userName?: string;
  /**
   * When true, the sphere loads the combined Friends World (/api/world/friends/…)
   * instead of a per-user world.  Auto-sync is disabled in this mode.
   */
  friendsWorld?: boolean;
}

/**
 * Formats a user's first name into possessive form:
 *   "Surya"  → "Surya's Music"
 *   "Chris"  → "Chris' Music"   (already ends in s)
 *   ""/ null → "Music"
 */
function possessiveHeadline(name: string | undefined): string {
  if (!name) return "Music";
  const first = name.split(" ")[0];
  return first.endsWith("s") ? `${first}' Music` : `${first}'s Music`;
}

// ── getDisplayTracks — canonical sort function (desktop + mobile share this) ─
// Extracted from the useMemo so it is a named, importable, testable unit.
// Both the desktop right-panel and the mobile bottom-sheet feed off the result
// of this function via the visibleTrackRows useMemo — there is no platform-specific
// sort path anywhere in WorldSphere.
//
// Sort priority:
//   1. Unheard (isUnheardForSelectedUser === true) — only when unheardMode
//   2. Live events (liveMode) — tracks with a concert bubble to the top
//   3. Social count (socialSort) — secondary: most-shared first
//   4. Default: original artist/name order from API
function getDisplayTracks(
  displayedTracks: TrackItem[],
  opts: {
    unheardMode:  boolean;
    liveMode:     boolean;
    socialSort:   boolean;
    liveEventMap: Record<string, LiveEvent | null>;
    tallyCount:   (t: TrackItem) => number;
  },
): TrackItem[] {
  const { unheardMode, liveMode, socialSort, liveEventMap, tallyCount } = opts;

  // Always enrich every track with its live event so the ticket icon is visible
  // regardless of whether liveMode is on. The sort block below is still gated
  // on liveMode, so ordering is only affected when the button is active.
  const enrich = (t: TrackItem): TrackItem => {
    const ev = liveEventMap[normalizeArtist(t.artist)];
    return ev ? { ...t, liveEvent: ev } : { ...t, liveEvent: undefined };
  };

  const base = displayedTracks.map(enrich);

  if (!unheardMode && !liveMode && !socialSort) return base;

  // Compare two tracks by unheard status: true first, false second, undefined last.
  // Returns 0 when unheardMode is off so it acts as a no-op secondary comparator.
  const cmpUnheard = (a: TrackItem, b: TrackItem): number => {
    if (!unheardMode) return 0;
    const av = a.isUnheardForSelectedUser;
    const bv = b.isUnheardForSelectedUser;
    if (av === bv) return 0;
    if (av === true)  return -1;
    if (bv === true)  return  1;
    if (av === false) return -1; // heard (false) sorts before no-spotifyId (undefined)
    return 1;
  };

  if (liveMode) {
    // Split: ticketed tracks float to top, others stay in their original order.
    // Ticketed rows sorted by social count (popularity) descending; ties preserve
    // original relative order (JS sort is stable in V8/SpiderMonkey).
    const withEv = base.filter(t => !!t.liveEvent);
    const noEv   = base.filter(t => !t.liveEvent);
    withEv.sort((a, b) => tallyCount(b) - tallyCount(a));
    return [...withEv, ...noEv];
  }

  if (socialSort) {
    return base.sort((a, b) => {
      const u = cmpUnheard(a, b); if (u !== 0) return u;
      return tallyCount(b) - tallyCount(a);
    });
  }

  return base.sort(cmpUnheard);
}

export default function WorldSphere({ userId, backHref, userName, friendsWorld = false }: WorldSphereProps = {}) {
  const { data: session, status: sessionStatus } = useSession();
  const sessionUserId = session?.user?.id ?? null;
  const router = useRouter();

  // True when viewing our own world (no userId prop, or userId matches session).
  // Friends World is never "own world" — auto-sync must never run there.
  const isOwnWorld = !friendsWorld && (!userId || userId === sessionUserId);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [loading,    setLoading]    = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const refreshingRef               = useRef(false);
  refreshingRef.current             = refreshing;
  const [worlds,     setWorlds]     = useState<Record<string, number>>({});
  const [error,      setError]      = useState<string | null>(null);

  // ── Auto-sync state (homepage only) ──────────────────────────────────────
  const [syncStatus,    setSyncStatus]    = useState<"idle" | "syncing" | "synced">("idle");
  const syncStatusTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const backoffUntilRef    = useRef(0);      // epoch ms — respect Retry-After
  const lastSyncRef        = useRef(0);      // epoch ms — last successful sync
  const autoSyncRef        = useRef<() => Promise<void>>(async () => {});

  // ── Genre / subgenre state ────────────────────────────────────────────────
  const [selected,         setSelected]         = useState<string | null>(null);
  const [tracks,           setTracks]           = useState<TrackItem[]>([]);
  // Mirror tracks in a ref so effects can read the current value without a
  // stale closure and without adding tracks to their dependency arrays.
  const tracksRef = useRef<TrackItem[]>([]);
  const [tracksLoading,    setTracksLoading]     = useState(false);
  const [subgenres,        setSubgenres]         = useState<SubgenreItem[]>([]);
  const [selectedSubgenre, setSelectedSubgenre]  = useState<string | null>(null);
  const [socialSort,        setSocialSort]        = useState(true);
  const [popoverData, setPopoverData] = useState<{
    trackId: string;
    users:   { id: string; name: string | null }[];
    top:     number;
    right:   number;
  } | null>(null);

  // ── Live events ───────────────────────────────────────────────────────────
  const [liveMode,     setLiveMode]     = useState(false);
  const [liveLoading,  setLiveLoading]  = useState(false);

  // ── Playlist push ─────────────────────────────────────────────────────────
  const [playlistLoading,   setPlaylistLoading]   = useState(false);
  const [playlistMsg,       setPlaylistMsg]       = useState<string | null>(null);
  // "signin"  → 401, user must sign in with Spotify
  // "reconnect" → 403 missing_scope, user must reconnect
  // null     → no auth error
  const [playlistAuthError, setPlaylistAuthError] = useState<"signin" | "reconnect" | null>(null);
  // Set of scope keys for playlists already created this session.
  // Initialised from sessionStorage so it survives same-tab navigations;
  // sessionStorage is cleared when the tab/window is closed.
  const [createdPlaylistKeys, setCreatedPlaylistKeys] = useState<Set<string>>(() => {
    if (typeof window === "undefined") return new Set<string>();
    try {
      const raw = sessionStorage.getItem("blueprint:createdPlaylists");
      return new Set<string>(raw ? (JSON.parse(raw) as string[]) : []);
    } catch {
      return new Set<string>();
    }
  });
  // Session-level artist cache: normalizedArtist → LiveEvent | null.
  // Survives genre switches so artists already searched aren't re-fetched.
  const [liveEventMap, setLiveEventMap] = useState<Record<string, LiveEvent | null>>({});

  // ── Friends World availability (individual worlds only) ───────────────────
  // Used to enable/disable the Venn button based on whether the current
  // genre (and optionally subgenre) exists in the Friends aggregate world.
  //   friendsGenres:    genre → count from /api/world/friends
  //   friendsSubgenres: genre → subgenre name list, fetched lazily per genre
  // friendsSubgenresFetchedRef tracks which genres have been requested so we
  // never issue duplicate fetches even if the effect re-fires.
  const [friendsGenres,    setFriendsGenres]    = useState<Record<string, number> | null>(null);
  const [friendsSubgenres, setFriendsSubgenres] = useState<Record<string, string[]>>({});
  const friendsSubgenresFetchedRef              = useRef<Set<string>>(new Set());

  // ── Venn origin route — Friends World back button target ────────────────
  // When this WorldSphere is the Friends World and the user arrived via a Venn
  // button, sessionStorage holds the origin route.  We read it once on mount
  // so the back button can return to the exact world the user came from.
  // For non-Friends worlds this stays null (they use backHref as-is).
  const [vennOriginRoute] = useState<string | null>(() => {
    if (!friendsWorld || typeof window === "undefined") return null;
    try {
      const raw = sessionStorage.getItem("blueprint:vennOriginState");
      return raw ? (JSON.parse(raw).route ?? null) : null;
    } catch { return null; }
  });

  // ── Substitute profile & Unheard mode ────────────────────────────────────
  // substituteProfile: set on /midvale, stored in sessionStorage.
  // Drives ?unheardForUserId on track API requests.
  // unheardMode: when true, sort isUnheardForSelectedUser===true tracks first.
  const [substituteProfile, setSubstituteProfile] = useState<{
    userId:   string;
    userName: string;
  } | null>(() => {
    if (typeof window === "undefined") return null;
    try {
      const raw = sessionStorage.getItem("blueprint:substituteProfile");
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  });
  const substituteProfileRef = useRef(substituteProfile);
  substituteProfileRef.current = substituteProfile;
  // Keep tracksRef in sync every render (used by unheardMode refetch effect).
  tracksRef.current = tracks;
  const [unheardMode, setUnheardMode] = useState(false);

  // ── showUnheard: whether to render the Unheard/star button ───────────────
  // • Homepage (/world — no userId, not friendsWorld)  → never show
  // • Individual world (/midvale/[userId])             → only when a substitute
  //   profile is selected AND it differs from this world's owner
  // • Friends World (/midvale/friends)                 → show when any substitute
  //   profile is selected
  const showUnheard: boolean = friendsWorld
    ? substituteProfile !== null
    : (userId !== undefined && substituteProfile !== null && substituteProfile.userId !== userId);

  const selectedSubgenreRef = useRef<string | null>(null);
  const [zoomSubgenre,     setZoomSubgenre]      = useState<string | null>(null);
  const zoomSubgenreRef    = useRef<string | null>(null);
  const [hoveredSubgenre,  setHoveredSubgenre]   = useState<string | null>(null);
  const hoveredSubgRef     = useRef<string | null>(null);

  // ── Audio playback ────────────────────────────────────────────────────────
  const [nowPlayingId,   setNowPlayingId]   = useState<string | null>(null);
  const [audioPlaying,   setAudioPlaying]   = useState(false);          // eslint-disable-line @typescript-eslint/no-unused-vars
  const audioRef                            = useRef<HTMLAudioElement | null>(null);
  const nowPlayingIdRef                     = useRef<string | null>(null);
  nowPlayingIdRef.current                   = nowPlayingId;
  const [playingTrack,   setPlayingTrack]   = useState<{id:string;name:string;artist:string;spotifyId?:string|null}|null>(null);
  const [pendingTrackId, setPendingTrackId] = useState<string | null>(null);
  const requestedTrackRef                   = useRef<string | null>(null);
  requestedTrackRef.current                 = pendingTrackId;
  const pendingAudioRef                     = useRef<HTMLAudioElement | null>(null);
  const [deezerPreviews, setDeezerPreviews] = useState<Record<string, string>>({});
  const deezerPreviewsRef                   = useRef<Record<string, string>>({});
  // Tracks the id of the single track that was clicked and confirmed to have no
  // available preview (Deezer returned null). Only that row shows "(No Preview)".
  const [noPreviewTrackId, setNoPreviewTrackId] = useState<string | null>(null);

  // ── Mobile state ──────────────────────────────────────────────────────────
  const [isMobile, setIsMobile] = useState(false);
  const isMobileRef             = useRef(false);
  isMobileRef.current           = isMobile;
  const [viewportH, setViewportH] = useState(0);
  const [sheetSnap, setSheetSnap] = useState<0|1|2>(0);
  const sheetSnapRef              = useRef<0|1|2>(0);
  sheetSnapRef.current            = sheetSnap;
  const mobileTracklistRef        = useRef<HTMLDivElement | null>(null);
  const sheetSwipeStartY          = useRef<number | null>(null);
  const sheetSwipeStartTime       = useRef<number>(0);
  const [zoomAbove2, setZoomAbove2] = useState(false);
  const zoomAbove2Ref               = useRef(false);

  // ── Rotation / zoom refs ──────────────────────────────────────────────────
  // Initial rotation: rx=0.3, ry=π — flipped 180° from y=0 so "Other" (which
  // lands near the default front face) is rotated to the back.
  const rotMatRef     = useRef<number[]>(matFromEuler(SPHERE_INIT_RX, SPHERE_INIT_RY));
  const grabVecRef    = useRef<V3 | null>(null);
  const pinchStateRef = useRef({ active: false, dist0: 0, zoom0: 1 });
  const zoomRef       = useRef(1);
  const zoomTargetRef = useRef(1);
  const subRegionRef  = useRef<Map<number, number>>(new Map());
  const activeSubsRef = useRef<SubgenreItem[]>([]);
  const subPolesRef   = useRef<{ name: string; pole: V3 }[]>([]);
  const dragRef       = useRef({ active: false, lx: 0, ly: 0, moved: false });
  const rafRef        = useRef<number>(0);
  const labelHitsRef  = useRef<{ name:string; subgenre?:string; x1:number; y1:number; x2:number; y2:number }[]>([]);
  const regionPolesRef = useRef<{ name:string; pole:V3 }[]>([]);
  const faceCentsRef   = useRef<V3[]>([]);
  const faceRegionRef  = useRef<number[]>([]);
  const hoveredRef     = useRef<{ genre:string; subgenre?:string } | null>(null);
  const autoSelectedRef = useRef(false);
  const selectedRef     = useRef<string | null>(null);
  selectedRef.current   = selected;
  const geoRef          = useRef<Geometry | null>(null);
  const dirtyRef        = useRef(true);
  const mouseMoveRafRef = useRef(false);

  // ── Friends World: URL-param auto-selection + centering ──────────────────
  // When navigating from an individual world via the Venn button, the URL
  // carries ?genre=... and optionally ?subgenre=...  These refs hold the
  // decoded values so they can be applied once data has loaded.
  const urlGenreParamRef    = useRef<string | null>(null);
  const pendingSubgenreRef  = useRef<string | null>(null);
  const urlParamAppliedRef  = useRef(false);
  // Captures toggle state to re-apply after the selected-change effect resets it.
  // Set by the Venn back-restore mount effect; consumed once by the selected effect.
  const pendingToggleRestoreRef = useRef<{
    socialSort: boolean; liveMode: boolean; unheardMode: boolean;
  } | null>(null);
  // urlSubgenreParamRef stores the original ?subgenre value permanently so
  // the subgenre geometry effect can rotate to it after poles are built.
  // (pendingSubgenreRef is cleared once the selection is applied.)
  const urlSubgenreParamRef   = useRef<string | null>(null);
  // One-shot flags: prevent re-centering after the user starts dragging.
  const urlGenreCenteredRef   = useRef(false);
  const urlSubgenreCenteredRef = useRef(false);

  // ── Mobile detection ──────────────────────────────────────────────────────
  useEffect(() => {
    if (typeof window === "undefined") return;
    const mq = window.matchMedia("(max-width: 768px)");
    setIsMobile(mq.matches);
    const h = (e: MediaQueryListEvent) => setIsMobile(e.matches);
    mq.addEventListener("change", h);
    return () => mq.removeEventListener("change", h);
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const update = () => setViewportH(window.innerHeight);
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  // ── Sheet ↔ selection sync (mobile only) ─────────────────────────────────
  useEffect(() => {
    if (!isMobile) return;
    if (selected !== null) setSheetSnap(prev => prev === 0 ? 1 : prev);
    else setSheetSnap(0);
  }, [selected, isMobile]);

  // ── Friends World: read ?genre / ?subgenre from URL on mount ─────────────
  useEffect(() => {
    if (!friendsWorld || typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    urlGenreParamRef.current    = params.get("genre");
    pendingSubgenreRef.current  = params.get("subgenre");
    urlSubgenreParamRef.current = params.get("subgenre"); // permanent copy for centering
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Friends World: apply genre param once world data has loaded ───────────
  useEffect(() => {
    if (!friendsWorld || loading || urlParamAppliedRef.current) return;
    const g = urlGenreParamRef.current;
    if (!g || !(g in worlds)) return;
    urlParamAppliedRef.current = true;
    setSelected(g);
    selectedRef.current   = g;
    // Zoom to genre level; zoom further if a subgenre will also be applied.
    zoomTargetRef.current = pendingSubgenreRef.current ? 3.2 : 2.5;
    dirtyRef.current      = true;
  }, [friendsWorld, loading, worlds]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Friends World: apply subgenre param once subgenres list arrives ───────
  useEffect(() => {
    const s = pendingSubgenreRef.current;
    if (!s || subgenres.length === 0) return;
    // Only apply if the subgenre actually exists in this world
    if (!subgenres.find(sg => sg.name === s)) {
      // Subgenre not present — clear the pending value, show graceful state
      pendingSubgenreRef.current = null;
      return;
    }
    pendingSubgenreRef.current     = null;
    selectedSubgenreRef.current    = s;
    setSelectedSubgenre(s);
    dirtyRef.current               = true;
  }, [subgenres]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Friends World availability — fetch genres once (individual worlds only) ─
  // Populates friendsGenres so we can immediately evaluate whether the current
  // genre exists in the Friends aggregate world.
  useEffect(() => {
    if (friendsWorld) return;
    fetch("/api/world/friends")
      .then(r => r.json())
      .then((d: Record<string, number>) => setFriendsGenres(d))
      .catch(() => {});
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Friends World availability — lazily fetch subgenres per genre ──────────
  // Triggered whenever the user selects a subgenre.  Uses a ref-based
  // fetch-guard so the same genre is never requested twice per session.
  // Uses selectedSubgenre (state) rather than focusedSubgenre (render-phase
  // derived value) so it can safely live in a useEffect dep array.
  useEffect(() => {
    if (friendsWorld || !selected || !selectedSubgenre) return;
    if (friendsSubgenresFetchedRef.current.has(selected)) return; // already fetched or in-flight
    friendsSubgenresFetchedRef.current.add(selected);
    const enc = encodeURIComponent(selected);
    fetch(`/api/world/friends/${enc}/subgenres`)
      .then(r => r.json())
      .then((d: { subgenres: { name: string }[] }) => {
        setFriendsSubgenres(prev => ({
          ...prev,
          [selected]: d.subgenres.map(sg => sg.name),
        }));
      })
      .catch(() => {
        // On error, allow a retry next time the effect fires
        friendsSubgenresFetchedRef.current.delete(selected);
      });
  }, [friendsWorld, selected, selectedSubgenre]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Substitute profile — listen for changes from /midvale selector ─────────
  // Handles two sources:
  //   1. "blueprint:substituteChange" custom event (same-tab, fired by SubstituteSelector)
  //   2. native "storage" event (cross-tab, fired when sessionStorage changes in another tab)
  useEffect(() => {
    const onSubChange = (e: Event) => {
      const profile = (e as CustomEvent<{ userId: string; userName: string } | null>).detail;
      setSubstituteProfile(profile);
      setUnheardMode(false); // reset when profile changes
    };
    const onStorage = (e: StorageEvent) => {
      if (e.key !== "blueprint:substituteProfile") return;
      try {
        const profile = e.newValue ? JSON.parse(e.newValue) : null;
        setSubstituteProfile(profile);
        setUnheardMode(false);
      } catch { /* malformed — ignore */ }
    };
    window.addEventListener("blueprint:substituteChange", onSubChange);
    window.addEventListener("storage", onStorage);
    return () => {
      window.removeEventListener("blueprint:substituteChange", onSubChange);
      window.removeEventListener("storage", onStorage);
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Auto-enable Unheard mode on Friends World arrival ────────────────────
  // When the user clicks Venn from any individual world, handleVennNavigate
  // writes "blueprint:autoEnableUnheard" to sessionStorage before navigating.
  // On Friends World mount we read it once, activate unheard mode, then delete
  // the flag so it never fires again unless a fresh Venn click sets it.
  useEffect(() => {
    if (!friendsWorld) return;
    try {
      const flag = sessionStorage.getItem("blueprint:autoEnableUnheard");
      if (flag === "true") {
        if (substituteProfileRef.current) setUnheardMode(true);
        sessionStorage.removeItem("blueprint:autoEnableUnheard");
      }
    } catch { /* sessionStorage unavailable — skip */ }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Venn back-restore: re-apply origin world state on return ─────────────
  // When the user returns from Friends World via the back button, this effect
  // reads blueprint:pendingRestore, validates the route matches, then:
  //   • Immediately writes camera refs (zoom + rotation) so the sphere is
  //     already at the right position before the first render frame.
  //   • Sets selected genre (triggers the selected-change effect → track fetch).
  //   • Stores subgenre in pendingSubgenreRef — applied by the existing
  //     subgenre-pending effect once the subgenre list loads.
  //   • Stores toggle state in pendingToggleRestoreRef — consumed by the
  //     selected-change effect to override its default reset.
  // Only runs on non-Friends worlds (individual + homepage).
  useEffect(() => {
    if (friendsWorld) return;
    try {
      const raw = sessionStorage.getItem("blueprint:pendingRestore");
      if (!raw) return;
      const state = JSON.parse(raw) as {
        route: string; genre: string | null; subgenre: string | null;
        zoom: number; rotMat: number[];
        socialSort: boolean; liveMode: boolean; unheardMode: boolean;
      };
      const myRoute = typeof window !== "undefined" ? window.location.pathname : (userId ? `/midvale/${userId}` : "/world");
      if (state.route !== myRoute) return; // restore meant for a different world
      sessionStorage.removeItem("blueprint:pendingRestore");

      // Restore camera immediately — refs are read by the render loop on the
      // very next RAF tick, so no re-render is needed for camera state.
      if (typeof state.zoom === "number") {
        zoomRef.current       = state.zoom;
        zoomTargetRef.current = state.zoom;
      }
      if (Array.isArray(state.rotMat) && state.rotMat.length === 9) {
        rotMatRef.current = [...state.rotMat];
      }

      // Restore genre/subgenre/toggles.
      // Setting selected genre triggers the selected-change effect which resets
      // toggles and subgenre — pendingToggleRestoreRef + pendingSubgenreRef let
      // us intercept that reset and re-apply the original values.
      if (state.genre) {
        pendingToggleRestoreRef.current = {
          socialSort:  state.socialSort  ?? true,
          liveMode:    state.liveMode    ?? false,
          unheardMode: state.unheardMode ?? false,
        };
        if (state.subgenre) {
          pendingSubgenreRef.current = state.subgenre;
          zoomTargetRef.current      = Math.max(state.zoom ?? 2.5, 3.2);
        }
        setSelected(state.genre);
        selectedRef.current = state.genre;
      }
    } catch { /* malformed storage or unavailable — skip */ }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Refetch tracks when substitute profile changes ────────────────────────
  // Only runs when a genre is already open. Leaves subgenres, sphere position,
  // and selected subgenre untouched — just refreshes track data with the new
  // ?unheardForUserId param so isUnheardForSelectedUser fields are up-to-date.
  useEffect(() => {
    const gen = selectedRef.current;
    if (!gen) return; // no genre open — nothing to refetch
    const enc = encodeURIComponent(gen);
    setTracksLoading(true);
    fetch(trackUrl(enc, substituteProfile?.userId ?? null))
      .then(r => r.json())
      .then(d => { setTracks(d.tracks ?? []); })
      .catch(() => {})
      .finally(() => setTracksLoading(false));
  }, [substituteProfile]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Refetch tracks when unheardMode turns ON and data is missing ─────────
  // When the user clicks "New to me" while tracks were fetched without
  // ?unheardForUserId (e.g. because unheard mode was off at load time on
  // desktop), isUnheardForSelectedUser is undefined for every track — the sort
  // has nothing to work with.  This effect detects that gap and forces a fresh
  // fetch with the substitute param so both desktop and mobile always have the
  // unheard data when the button is active.
  //
  // Only fires when:
  //   • unheardMode just turned true
  //   • a substitute profile is set
  //   • current tracks lack isUnheardForSelectedUser (fetched without the param)
  useEffect(() => {
    if (!unheardMode) return;
    const sub = substituteProfileRef.current;
    if (!sub) return;
    const gen = selectedRef.current;
    if (!gen) return;
    // If ANY track already has the field (true or false), data is present — skip.
    if (tracksRef.current.some(t => t.isUnheardForSelectedUser !== undefined)) return;
    // Tracks are missing unheard data — re-fetch now with the substitute ID.
    const enc = encodeURIComponent(gen);
    setTracksLoading(true);
    fetch(trackUrl(enc, sub.userId))
      .then(r => r.json())
      .then(d => { setTracks(d.tracks ?? []); })
      .catch(() => {})
      .finally(() => setTracksLoading(false));
  }, [unheardMode]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Body scroll lock when exploring on mobile ────────────────────────────
  useEffect(() => {
    if (!isMobile) return;
    if (selected !== null) {
      document.documentElement.style.overflow = "hidden";
      document.body.style.overflow            = "hidden";
    } else {
      document.documentElement.style.overflow = "";
      document.body.style.overflow            = "";
    }
    return () => {
      document.documentElement.style.overflow = "";
      document.body.style.overflow            = "";
    };
  }, [isMobile, selected]);

  // zoomAbove2 is now driven from the RAF animate() loop — no setInterval needed.

  // ── Data fetching ─────────────────────────────────────────────────────────

  // Appends ?userId=<id> when this component is rendering a specific user's world.
  const userParam = userId ? `?userId=${encodeURIComponent(userId)}` : "";

  // URL builders — Friends World uses a separate API tree; user worlds use the
  // standard /api/world/… paths with an optional ?userId param.
  const worldUrl    = friendsWorld
    ? "/api/world/friends"
    : `/api/world${userParam}`;
  const genreUrl    = (enc: string) => friendsWorld
    ? `/api/world/friends/${enc}`
    : `/api/world/${enc}${userParam}`;
  const subgenreUrl = (enc: string) => friendsWorld
    ? `/api/world/friends/${enc}/subgenres`
    : `/api/world/${enc}/subgenres${userParam}`;

  // Builds a full tracklist URL including the optional ?unheardForUserId param.
  // Reads substituteProfileRef.current so it always picks up the latest value
  // even when called from inside a useEffect with a stale closure.
  const trackUrl = (enc: string, uid?: string | null): string => {
    const base = genreUrl(enc);
    const id   = uid ?? substituteProfileRef.current?.userId ?? null;
    if (!id) return base;
    const sep  = base.includes("?") ? "&" : "?";
    return `${base}${sep}unheardForUserId=${encodeURIComponent(id)}`;
  };

  async function loadWorld() {
    try {
      setLoading(true); setError(null);
      const res = await fetch(worldUrl);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "World fetch failed");
      setWorlds(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally { setLoading(false); }
  }

  async function refreshFromSpotify() {
    try {
      setRefreshing(true); setError(null);
      const r = await fetch("/api/spotify/import");
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "Import failed");
      await loadWorld();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally { setRefreshing(false); }
  }

  useEffect(() => { loadWorld(); }, []);

  // ── Auto-sync (homepage / own-world only, not Midvale roommate views) ─────
  //
  // autoSync is redefined on every render so it always closes over fresh state.
  // autoSyncRef.current is updated each render so interval/event handlers
  // always call the latest version without stale closures.

  const autoSync = async () => {
    if (!isOwnWorld) {
      console.log("[autoSync] blocked", { userId, sessionUserId, isOwnWorld });
      return;
    }
    if (refreshingRef.current) return;           // manual sync already running
    if (Date.now() < backoffUntilRef.current) return; // rate-limit backoff

    console.log("[autoSync] running");
    try {
      setSyncStatus("syncing");
      const r = await fetch("/api/spotify/sync", { method: "POST" });

      if (r.status === 429) {
        const retryAfter = parseInt(r.headers.get("Retry-After") ?? "60", 10);
        backoffUntilRef.current = Date.now() + retryAfter * 1_000;
        console.warn(`[autoSync] rate limited — backing off ${retryAfter}s`);
        setSyncStatus("idle");
        return;
      }

      if (!r.ok) { setSyncStatus("idle"); return; }

      // Refresh world counts (drives sphere geometry + desktop panel counts)
      await loadWorld();

      // If a genre is zoomed in, silently refresh its tracks + subgenres
      if (selectedRef.current) {
        const enc = encodeURIComponent(selectedRef.current);
        fetch(`/api/world/${enc}`)
          .then(res => res.json())
          .then(d  => setTracks(d.tracks ?? []))
          .catch(() => {});
        fetch(`/api/world/${enc}/subgenres`)
          .then(res => res.json())
          .then(d  => setSubgenres(d.subgenres ?? []))
          .catch(() => {});
      }

      lastSyncRef.current = Date.now();
      setSyncStatus("synced");
      if (syncStatusTimerRef.current) clearTimeout(syncStatusTimerRef.current);
      syncStatusTimerRef.current = setTimeout(() => setSyncStatus("idle"), 2_500);
    } catch {
      setSyncStatus("idle");
    }
  };
  // Keep ref up-to-date so interval/event callbacks always use the latest closure
  autoSyncRef.current = autoSync;

  // Poll every 90 s while page is visible — mount/teardown whenever isOwnWorld changes
  useEffect(() => {
    console.log("[autoSync] mounted", { userId, sessionUserId, isOwnWorld });
    if (!isOwnWorld) return; // roommate worlds — no polling
    const INTERVAL_MS = 90_000;
    const id = setInterval(() => {
      if (Date.now() - lastSyncRef.current >= INTERVAL_MS) {
        autoSyncRef.current();
      }
    }, INTERVAL_MS);
    return () => clearInterval(id);
  }, [isOwnWorld]); // eslint-disable-line react-hooks/exhaustive-deps

  // Trigger once when the tab becomes visible again (after switching away)
  useEffect(() => {
    if (!isOwnWorld) return;
    const onVisible = () => {
      if (document.visibilityState === "visible" &&
          Date.now() - lastSyncRef.current >= 60_000) {
        autoSyncRef.current();
      }
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, [isOwnWorld]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Fetch tracks + subgenres + Deezer previews when genre selected ────────
  useEffect(() => {
    hoveredSubgRef.current = null; setHoveredSubgenre(null);
    if (!selected) {
      setTracks([]); setSubgenres([]);
      setSelectedSubgenre(null); selectedSubgenreRef.current = null;
      setZoomSubgenre(null);     zoomSubgenreRef.current     = null;
      deezerPreviewsRef.current = {}; setDeezerPreviews({});
      setSocialSort(false); setLiveMode(false);
      return;
    }
    // Apply pending toggle restore (set by Venn back-restore effect) instead of
    // the default reset, so returning users see the same socialSort/live/unheard
    // state they left with.  Consumed once; null after first selected change.
    const ptgl = pendingToggleRestoreRef.current;
    pendingToggleRestoreRef.current = null;
    setSocialSort(ptgl ? ptgl.socialSort  : true);
    setLiveMode  (ptgl ? ptgl.liveMode    : false);
    setUnheardMode(ptgl ? ptgl.unheardMode : false);
    setSelectedSubgenre(null); selectedSubgenreRef.current = null;
    setZoomSubgenre(null);     zoomSubgenreRef.current     = null;
    deezerPreviewsRef.current = {}; setDeezerPreviews({});

    const enc = encodeURIComponent(selected);
    setTracksLoading(true);
    // trackUrl() reads substituteProfileRef.current so the unheard param is
    // included immediately if a substitute profile is already selected.
    fetch(trackUrl(enc))
      .then(r => r.json())
      .then(d => {
        setTracks(d.tracks ?? []);
        if (Array.isArray(d.subgenres)) {
          setSubgenres(d.subgenres);
        } else {
          // Fallback: subgenres not bundled in response — fetch separately
          fetch(subgenreUrl(enc)).then(r=>r.json()).then(d2=>setSubgenres(d2.subgenres??[])).catch(()=>setSubgenres([]));
        }
      })
      .catch(() => setTracks([]))
      .finally(() => setTracksLoading(false));
  }, [selected]); // eslint-disable-line react-hooks/exhaustive-deps

  // hoveredSubgenre is now driven directly from onMouseMove/onTouchMove — no setInterval needed.

  // ── playTrack ─────────────────────────────────────────────────────────────
  const playTrack = (t: TrackItem) => {
    const previewUrl = deezerPreviewsRef.current[t.id] ?? t.previewUrl ?? null;
    if (!previewUrl) {
      if (nowPlayingIdRef.current === t.id) {
        if (audioRef.current) { audioRef.current.pause(); audioRef.current = null; }
        setNowPlayingId(null); setAudioPlaying(false); setPlayingTrack(null); return;
      }
      if (requestedTrackRef.current === t.id) return;
      setNoPreviewTrackId(null); // clear any previous "No Preview" label while fetching
      requestedTrackRef.current = t.id; setPendingTrackId(t.id);
      if (pendingAudioRef.current) { pendingAudioRef.current.src = ""; pendingAudioRef.current = null; }
      const pa = new Audio(); pa.volume = 0.8; pendingAudioRef.current = pa;
      fetch(`/api/preview?track=${encodeURIComponent(t.name)}&artist=${encodeURIComponent(t.artist)}`)
        .then(r=>r.json()).then((d:{previewUrl:string|null})=>{
          if (requestedTrackRef.current !== t.id) return;
          requestedTrackRef.current = null; setPendingTrackId(null);
          if (!d.previewUrl) { setNoPreviewTrackId(t.id); return; }
          deezerPreviewsRef.current[t.id] = d.previewUrl; setDeezerPreviews(p=>({...p,[t.id]:d.previewUrl!}));
          const audio = pendingAudioRef.current; if (!audio) return;
          audio.src = d.previewUrl;
          if (audioRef.current) { audioRef.current.pause(); audioRef.current.currentTime = 0; }
          audio.addEventListener("ended",()=>{setAudioPlaying(false);setNowPlayingId(null);setPlayingTrack(null);});
          audio.addEventListener("error",()=>{delete deezerPreviewsRef.current[t.id];setDeezerPreviews(p=>{const n={...p};delete n[t.id];return n;});setAudioPlaying(false);setNowPlayingId(null);setPlayingTrack(null);});
          audioRef.current = audio; pendingAudioRef.current = null;
          setNowPlayingId(t.id); setPlayingTrack({id:t.id,name:t.name,artist:t.artist,spotifyId:t.spotifyId??null}); setAudioPlaying(true);
          const p = audio.play();
          if (p) p.catch(()=>{if(audioRef.current===audio)audioRef.current=null;setAudioPlaying(false);setNowPlayingId(null);setPlayingTrack(null);});
        }).catch(()=>{});
      return;
    }
    if (nowPlayingIdRef.current === t.id) {
      if (audioRef.current){audioRef.current.pause();audioRef.current.currentTime=0;audioRef.current=null;}
      setAudioPlaying(false);setNowPlayingId(null);setPlayingTrack(null);return;
    }
    setNoPreviewTrackId(null);
    requestedTrackRef.current=null;setPendingTrackId(null);
    if(pendingAudioRef.current){pendingAudioRef.current.src="";pendingAudioRef.current=null;}
    if(audioRef.current){audioRef.current.pause();audioRef.current.currentTime=0;}
    const audio=new Audio(previewUrl); audio.volume=0.8;
    audio.addEventListener("ended",()=>{setAudioPlaying(false);setNowPlayingId(null);setPlayingTrack(null);});
    audio.addEventListener("error",()=>{delete deezerPreviewsRef.current[t.id];setDeezerPreviews(p=>{const n={...p};delete n[t.id];return n;});setAudioPlaying(false);setNowPlayingId(null);setPlayingTrack(null);});
    audioRef.current=audio;setNowPlayingId(t.id);setPlayingTrack({id:t.id,name:t.name,artist:t.artist,spotifyId:t.spotifyId??null});setAudioPlaying(true);
    const p=audio.play();
    if(p)p.catch(err=>{if(err.name!=="AbortError"){delete deezerPreviewsRef.current[t.id];setDeezerPreviews(p2=>{const n={...p2};delete n[t.id];return n;});setNowPlayingId(null);setAudioPlaying(false);setPlayingTrack(null);}else{setAudioPlaying(false);}});
  };

  // ── Mobile zoom pill handlers ─────────────────────────────────────────────
  const handleZoomPlus = () => {
    if (!selectedRef.current || zoomAbove2Ref.current) return;
    zoomTargetRef.current = 2.5;
  };
  const handleZoomMinus = () => {
    if (!selectedRef.current) return;
    if (zoomAbove2Ref.current) {
      zoomTargetRef.current = 1.5;
      selectedSubgenreRef.current = null; setSelectedSubgenre(null);
      zoomSubgenreRef.current     = null; setZoomSubgenre(null);
    } else {
      zoomTargetRef.current = 1;
      autoSelectedRef.current = false;
      selectedSubgenreRef.current = null; setSelectedSubgenre(null);
      zoomSubgenreRef.current     = null; setZoomSubgenre(null);
      setSelected(null);
    }
  };

  // ── Canvas / render + interaction ─────────────────────────────────────────
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || loading || Object.keys(worlds).length === 0) return;

    // High-DPI: cap at 1.5× on mobile, 2× on desktop
    const dpr = Math.min(window.devicePixelRatio || 1, isMobileRef.current ? 1.5 : 2);

    const sync = () => {
      const w = canvas.offsetWidth, h = canvas.offsetHeight;
      if (!w || !h) return;
      canvas.width  = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      dirtyRef.current = true;
    };
    sync();
    const ro = new ResizeObserver(sync);
    ro.observe(canvas);

    const { verts, faces } = buildIcosphere(2);
    const entries = Object.entries(worlds);
    const total   = entries.reduce((s,[,c])=>s+c,0) || 1;
    const names   = entries.map(([n])=>n);
    const bonuses = entries.map(([,c])=>(Math.PI/4)*Math.sqrt(c/total));
    const cents   = faces.map(f=>triCentroid(verts,f));

    const { region: rawRegion, poles: finalPoles } = lloydRelax(cents, fiboPoles(names.length), bonuses, 8);
    regionPolesRef.current = names.map((n,i)=>({name:n,pole:finalPoles[i]}));

    const adj    = buildAdjacency(faces);
    const region = removeIslands(rawRegion, adj, names.length);

    // Expose per-face data for accurate click/tap hit testing
    faceCentsRef.current  = cents;
    faceRegionRef.current = region;

    const rgbMap: [number,number,number][] = names.map(n=>hexRgb(COLORS[n]??"#71717a"));

    // Store geometry in ref so drawFrame and subgenre effect can read it
    geoRef.current = { verts, faces, cents, adj, names, region, rgbMap };

    // ── Venn / URL-param genre centering ────────────────────────────────────
    // If the page was opened with ?genre=... (e.g. via the Venn button), rotate
    // the sphere so that genre region faces the camera immediately.
    // This runs exactly once per navigation; urlGenreCenteredRef prevents any
    // re-centering after the user starts dragging.
    // When a subgenre is also targeted (urlSubgenreParamRef is set), we still
    // do a quick genre-level center here so something useful shows immediately;
    // the subgenre geometry effect below will then refine to the subgenre pole.
    if (urlGenreParamRef.current && !urlGenreCenteredRef.current) {
      const entry = regionPolesRef.current.find(r => r.name === urlGenreParamRef.current);
      if (entry) {
        urlGenreCenteredRef.current = true;
        // Rotate: bring genre pole to (0,0,1) — the "facing camera" direction.
        const q = quatFromTo(entry.pole, [0, 0, 1] as V3);
        rotMatRef.current = mat3Ortho(matFromQuat(q));
      }
    }

    dirtyRef.current = true;

    const FOV = 900;
    const MIN_ZOOM = 1.0, MAX_ZOOM = 5.0;
    let snapZoom = false;  // set on mobile pinch-end for immediate snap

    // ── drawFrame ──────────────────────────────────────────────────────────
    function drawFrame(): boolean {
      const geo = geoRef.current; if (!geo) return false;
      const { verts, faces, cents, adj, names, region, rgbMap } = geo;

      // Zoom lerp (desktop) / snap (mobile pinch end)
      if (snapZoom) { zoomRef.current = zoomTargetRef.current; snapZoom = false; }
      else           { zoomRef.current += (zoomTargetRef.current - zoomRef.current) * 0.10; }

      const canvas = canvasRef.current; if (!canvas) return false;
      const W = canvas.offsetWidth, H = canvas.offsetHeight;
      if (!W || !H) return false;
      const ctx = canvas.getContext("2d"); if (!ctx) return false;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);  // HiDPI

      const R = Math.min(W,H) * 0.34 * zoomRef.current;
      const cx = W/2, cy = H/2;
      const [m0,m1,m2,m3,m4,m5,m6,m7,m8] = rotMatRef.current;
      labelHitsRef.current = [];
      ctx.clearRect(0, 0, W, H);

      const atmo = ctx.createRadialGradient(cx,cy,R*0.82,cx,cy,R*1.22);
      atmo.addColorStop(0,"rgba(70,70,180,0.13)"); atmo.addColorStop(1,"rgba(0,0,0,0)");
      ctx.beginPath(); ctx.arc(cx,cy,R*1.22,0,Math.PI*2); ctx.fillStyle=atmo; ctx.fill();

      const pv = verts.map(([x,y,z])=>{
        const xs=m0*x+m1*y+m2*z, ys=m3*x+m4*y+m5*z, zs=m6*x+m7*y+m8*z;
        const s=FOV/(FOV+zs);
        return {sx:cx+xs*R*s, sy:cy+ys*R*s, z:zs};
      });

      const fd=faces.map((tri,i)=>({tri,fi:i,depth:(pv[tri[0]].z+pv[tri[1]].z+pv[tri[2]].z)/3,ri:region[i]})).sort((a,b)=>a.depth-b.depth);
      const selectedIdx=selectedRef.current!==null?names.indexOf(selectedRef.current):-1;
      const hoveredGenre=hoveredRef.current?.genre??null;
      const hoveredSubName=hoveredRef.current?.subgenre??null;
      const hoveredIdx=hoveredGenre!==null?names.indexOf(hoveredGenre):-1;
      const subgReveal=Math.min(1,Math.max(0,(zoomRef.current-1.6)/0.5));

      for (const {tri,fi,depth,ri} of fd) {
        const [ia,ib,ic]=tri;
        const isFront=depth>=0, isSelected=ri===selectedIdx, isHovG=ri===hoveredIdx&&!isSelected;
        const subIdx=isSelected&&zoomRef.current>=1.6?subRegionRef.current.get(fi):undefined;
        const showSub=subIdx!==undefined;
        const subName=showSub?activeSubsRef.current[subIdx!]?.name:undefined;
        const isHovSub=showSub&&!!subName&&subName===hoveredSubName;
        const isClickSub=showSub&&!!subName&&subName===selectedSubgenreRef.current;
        const sibHov=showSub&&!!hoveredSubName&&!isHovSub;
        let [r,g,b]=rgbMap[ri];
        if(showSub){const sc=0.55;r=Math.round(r*sc);g=Math.round(g*sc);b=Math.round(b*sc);}
        ctx.beginPath();ctx.moveTo(pv[ia].sx,pv[ia].sy);ctx.lineTo(pv[ib].sx,pv[ib].sy);ctx.lineTo(pv[ic].sx,pv[ic].sy);ctx.closePath();
        if(isFront){
          const hs=selectedIdx>=0;
          const fa=isClickSub?0.52*subgReveal:isHovSub?0.35*subgReveal:sibHov?0.06*subgReveal:showSub?0.08*subgReveal:isSelected?0.28:isHovG?0.15:hs?0.015:0.02;
          ctx.fillStyle=`rgba(${r},${g},${b},${fa})`;ctx.fill();
          const ea=isClickSub?0.90*subgReveal:isHovSub?0.65*subgReveal:sibHov?0.03*subgReveal:showSub?0.05*subgReveal:isSelected?1.0:isHovG?0.95:hs?0.60:0.82;
          ctx.strokeStyle=`rgba(${r},${g},${b},${ea})`;
          ctx.lineWidth=isClickSub?0.70:isHovSub?0.55:showSub?0.30:isSelected?1.4:isHovG?1.2:hs?0.75:0.9;ctx.stroke();
        } else {
          const t=Math.max(0,(depth+0.8)/0.8)*0.13;ctx.strokeStyle=`rgba(${r},${g},${b},${t.toFixed(3)})`;ctx.lineWidth=0.4;ctx.stroke();
        }
      }

      // Subgenre boundary edges
      if (zoomRef.current>=1.6&&selectedIdx>=0&&subRegionRef.current.size>0) {
        const [br,bg,bb]=rgbMap[selectedIdx]; ctx.save();
        ctx.shadowColor=`rgba(${br},${bg},${bb},${(0.55*subgReveal).toFixed(3)})`;ctx.shadowBlur=5;
        ctx.strokeStyle=`rgba(${br},${bg},${bb},${(0.82*subgReveal).toFixed(3)})`;ctx.lineWidth=1.6;ctx.lineCap="round";
        const de=new Set<string>();
        for(const{fi,depth,ri} of fd){if(ri!==selectedIdx||depth<0)continue;const siA=subRegionRef.current.get(fi);if(siA===undefined)continue;for(const ni of adj[fi]){const siB=subRegionRef.current.get(ni);if(siB===undefined||siB===siA)continue;const fv=faces[fi],nv=faces[ni],sh=fv.filter(v=>nv.includes(v));if(sh.length!==2)continue;const k=sh[0]<sh[1]?`${sh[0]}:${sh[1]}`:`${sh[1]}:${sh[0]}`;if(de.has(k))continue;de.add(k);ctx.beginPath();ctx.moveTo(pv[sh[0]].sx,pv[sh[0]].sy);ctx.lineTo(pv[sh[1]].sx,pv[sh[1]].sy);ctx.stroke();}}
        ctx.restore();
      }

      // Main genre plate boundary
      if (selectedIdx>=0) {
        const [pr,pg,pb]=rgbMap[selectedIdx]; ctx.save();
        ctx.shadowColor=`rgba(${pr},${pg},${pb},0.85)`;ctx.shadowBlur=10;ctx.strokeStyle=`rgba(${pr},${pg},${pb},1.0)`;ctx.lineWidth=3.0;ctx.lineCap="round";
        const dp=new Set<string>();
        for(const{fi,depth,ri} of fd){if(ri!==selectedIdx||depth<0)continue;for(const ni of adj[fi]){if(region[ni]===selectedIdx)continue;const fv=faces[fi],nv=faces[ni],sh=fv.filter(v=>nv.includes(v));if(sh.length!==2)continue;const k=sh[0]<sh[1]?`${sh[0]}:${sh[1]}`:`${sh[1]}:${sh[0]}`;if(dp.has(k))continue;dp.add(k);ctx.beginPath();ctx.moveTo(pv[sh[0]].sx,pv[sh[0]].sy);ctx.lineTo(pv[sh[1]].sx,pv[sh[1]].sy);ctx.stroke();}}
        ctx.restore();
      }

      // Genre labels (short names)
      const acc: Record<number,{sx:number;sy:number;n:number}>={};
      for(const{tri,depth,ri} of fd){if(depth<0)continue;const[ia,ib,ic]=tri;const lx=(pv[ia].sx+pv[ib].sx+pv[ic].sx)/3,ly=(pv[ia].sy+pv[ib].sy+pv[ic].sy)/3;if(!acc[ri])acc[ri]={sx:0,sy:0,n:0};acc[ri].sx+=lx;acc[ri].sy+=ly;acc[ri].n++;}
      ctx.textAlign="center";ctx.textBaseline="middle";
      for(const[riStr,a] of Object.entries(acc)){
        if(a.n<4)continue;
        const ri=Number(riStr),isSelG=ri===selectedIdx;
        // On mobile, hide the selected genre label when deeply zoomed in (subgenre labels dominate)
        if(isMobileRef.current&&isSelG&&zoomRef.current>=1.9)continue;
        const rawLx=a.sx/a.n,rawLy=a.sy/a.n;
        const lx=isSelG?Math.max(80,Math.min(W-80,rawLx)):rawLx;
        const ly=isSelG?Math.max(24,Math.min(H*0.88,rawLy)):rawLy;
        const name=names[ri],label=shortLabel(name);
        const[r,g,b]=rgbMap[ri];
        const isThisHov=ri===hoveredIdx;
        const labelDim=isSelG||isThisHov?1.0:selectedIdx>=0?0.50:1.0;
        const fs=isMobileRef.current?(isSelG?15:13):(isSelG?15:13);
        ctx.globalAlpha=labelDim;ctx.font=`700 ${fs}px system-ui, sans-serif`;
        const tw=ctx.measureText(label).width,pad=8,rad=8;
        const bx=lx-tw/2-pad,by=ly-fs/2-pad,bw=tw+pad*2,bh=fs+pad*2;
        ctx.save();ctx.shadowColor="rgba(0,0,0,0.75)";ctx.shadowBlur=14;ctx.fillStyle=isSelG?"rgba(8,8,16,0.90)":"rgba(8,8,16,0.72)";ctx.beginPath();ctx.roundRect(bx,by,bw,bh,rad);ctx.fill();ctx.restore();
        if(isSelG){ctx.strokeStyle=`rgba(${r},${g},${b},0.7)`;ctx.lineWidth=1;ctx.beginPath();ctx.roundRect(bx,by,bw,bh,rad);ctx.stroke();}
        ctx.fillStyle=`rgb(${r},${g},${b})`;ctx.fillText(label,lx,ly);ctx.globalAlpha=1.0;
        labelHitsRef.current.push({name,x1:bx,y1:by,x2:bx+bw,y2:by+bh});
      }

      // Subgenre labels
      if (zoomRef.current>=1.6&&selectedIdx>=0) {
        const stm=new Map<number,{sx:number;sy:number;n:number}>();
        for(const{tri,fi,depth,ri} of fd){if(ri!==selectedIdx||depth<-0.1)continue;const si=subRegionRef.current.get(fi);if(si===undefined)continue;const[ia,ib,ic]=tri;const tsx=(pv[ia].sx+pv[ib].sx+pv[ic].sx)/3,tsy=(pv[ia].sy+pv[ib].sy+pv[ic].sy)/3;const a=stm.get(si);if(a){a.sx+=tsx;a.sy+=tsy;a.n++;}else stm.set(si,{sx:tsx,sy:tsy,n:1});}
        // On mobile, subgenre labels appear later (zoom >= 1.9)
        const zoomThresh=isMobileRef.current?1.9:1.6;
        const labelReveal=Math.min(1,Math.max(0,(zoomRef.current-zoomThresh)/0.2));
        ctx.globalAlpha=labelReveal;
        activeSubsRef.current.forEach((sub,si)=>{
          const a=stm.get(si);if(!a)return;
          const lx=a.sx/a.n,ly=a.sy/a.n;
          const n2=activeSubsRef.current.length,t=n2>1?1-si/(n2-1):0.5,scale=0.45+0.55*t;
          const[pr,pg,pb]=rgbMap[selectedIdx];
          const cr=Math.round(pr*scale),cg=Math.round(pg*scale),cb=Math.round(pb*scale);
          const isAS=selectedSubgenreRef.current===sub.name,isHS=hoveredSubName===sub.name,subLit=isAS||isHS;
          const fs=isMobileRef.current?(subLit?14:12):(subLit?12:11);
          ctx.font=`${subLit?700:600} ${fs}px system-ui, sans-serif`;
          const tw=ctx.measureText(sub.name).width,pad=6,rad=6;
          const bx=lx-tw/2-pad,by=ly-fs/2-pad,bw=tw+pad*2,bh=fs+pad*2;
          ctx.save();ctx.shadowColor=isHS?`rgba(${cr},${cg},${cb},0.45)`:"rgba(0,0,0,0.55)";ctx.shadowBlur=isHS?12:8;
          ctx.fillStyle=isAS?`rgba(${cr},${cg},${cb},0.18)`:isHS?`rgba(${cr},${cg},${cb},0.12)`:"rgba(8,8,16,0.60)";
          ctx.beginPath();ctx.roundRect(bx,by,bw,bh,rad);ctx.fill();ctx.restore();
          if(isAS){ctx.strokeStyle=`rgba(${cr},${cg},${cb},1.0)`;ctx.lineWidth=1.5;ctx.beginPath();ctx.roundRect(bx,by,bw,bh,rad);ctx.stroke();}
          else if(isHS){ctx.strokeStyle=`rgba(${cr},${cg},${cb},0.60)`;ctx.lineWidth=1.0;ctx.beginPath();ctx.roundRect(bx,by,bw,bh,rad);ctx.stroke();}
          ctx.fillStyle=isHS?`rgb(${cr},${cg},${cb})`:`rgba(${cr},${cg},${cb},0.80)`;ctx.fillText(sub.name,lx,ly);
          labelHitsRef.current.push({name:selectedRef.current!,subgenre:sub.name,x1:bx,y1:by,x2:bx+bw,y2:by+bh});
        });
        ctx.globalAlpha=1.0;
      }
      ctx.textBaseline="alphabetic";
      return true;
    }

    // ── Shared zoom helper ────────────────────────────────────────────────
    const applyZoomDelta = (rawDelta: number) => {
      const cd=Math.max(-50,Math.min(50,rawDelta));
      const newT=Math.max(MIN_ZOOM,Math.min(MAX_ZOOM,zoomTargetRef.current*(1-cd*0.008)));
      zoomTargetRef.current=newT;
      if(newT>=1.2&&selectedRef.current===null&&regionPolesRef.current.length>0){
        const[,,,,,,rm6,rm7,rm8]=rotMatRef.current;
        let bn=regionPolesRef.current[0].name,bz=-Infinity;
        for(const{name,pole:[px,py,pz]} of regionPolesRef.current){const z2=rm6*px+rm7*py+rm8*pz;if(z2>bz){bz=z2;bn=name;}}
        autoSelectedRef.current=true;setSelected(bn);
      }
      if(newT<2.0){if(zoomSubgenreRef.current!==null){zoomSubgenreRef.current=null;setZoomSubgenre(null);}if(selectedSubgenreRef.current!==null){selectedSubgenreRef.current=null;setSelectedSubgenre(null);}}
      if(newT<=MIN_ZOOM+0.1&&selectedRef.current!==null){autoSelectedRef.current=false;selectedSubgenreRef.current=null;setSelectedSubgenre(null);zoomSubgenreRef.current=null;setZoomSubgenre(null);setSelected(null);}
    };

    // ── Wheel handler ──────────────────────────────────────────────────────
    const onWheel = (e: WheelEvent) => {
      const rect=canvas.getBoundingClientRect();
      const W2=canvas.clientWidth,H2=canvas.clientHeight;
      const R2=Math.min(W2,H2)*0.34*zoomRef.current;
      const dx=e.clientX-rect.left-W2/2,dy=e.clientY-rect.top-H2/2;
      const over=dx*dx+dy*dy<=R2*R2;
      if(e.ctrlKey&&over&&e.deltaY>0&&zoomTargetRef.current<=MIN_ZOOM+0.02){e.preventDefault();return;}
      if(!over)return;
      if(e.deltaY>0&&zoomTargetRef.current<=MIN_ZOOM+0.02)return;
      if(!(selectedRef.current!==null||zoomTargetRef.current>1.05)&&e.deltaY>0)return;
      e.preventDefault();applyZoomDelta(e.deltaY);
    };
    canvas.addEventListener("wheel", onWheel, { passive: false });

    // ── Safari GestureEvent (trackpad pinch fallback) ─────────────────────
    let gestureStartScale=1;
    const onGestureStart=(e:Event)=>{gestureStartScale=(e as any).scale??1;};
    const onGestureChange=(e:Event)=>{const sc=(e as any).scale??1;if(sc<gestureStartScale&&zoomTargetRef.current<=MIN_ZOOM+0.02)e.preventDefault();};
    const onGestureEnd=(e:Event)=>{if(zoomTargetRef.current<=MIN_ZOOM+0.02)e.preventDefault();gestureStartScale=1;};
    canvas.addEventListener("gesturestart",  onGestureStart,  { passive: true  });
    canvas.addEventListener("gesturechange", onGestureChange, { passive: false });
    canvas.addEventListener("gestureend",    onGestureEnd,    { passive: false });

    // ── Touch handlers (mobile: arcball drag + pinch zoom) ─────────────────
    let touchDrag  = { active: false, lx: 0, ly: 0, moved: false };
    let touchGrabVec: V3 | null = null;
    let pinchActive = pinchStateRef.current.active;
    let pinchDist0  = pinchStateRef.current.dist0;
    let pinchZoom0  = pinchStateRef.current.zoom0;
    let lastTapTime = 0, lastTapX = 0, lastTapY = 0;

    const touchOverSphere = (cx2: number, cy2: number) => {
      const rect2=canvas.getBoundingClientRect();
      const mx2=cx2-rect2.left,my2=cy2-rect2.top;
      const W2=canvas.clientWidth,H2=canvas.clientHeight;
      const R2=Math.min(W2,H2)*0.40*zoomRef.current;
      const dx2=mx2-W2/2,dy2=my2-H2/2;
      return dx2*dx2+dy2*dy2<=R2*R2;
    };

    const onTouchStart=(e:TouchEvent)=>{
      const touches=e.touches;
      if(touches.length===1){
        const t=touches[0];
        if(!touchOverSphere(t.clientX,t.clientY))return;
        e.preventDefault();
        touchDrag={active:true,lx:t.clientX,ly:t.clientY,moved:false};
        {const rect2=canvas.getBoundingClientRect();const W2=canvas.clientWidth,H2=canvas.clientHeight;const R2=Math.min(W2,H2)*0.35*zoomRef.current;touchGrabVec=arcballVec(t.clientX-rect2.left,t.clientY-rect2.top,W2/2,H2/2,R2);}
        const now=performance.now(),dtx=t.clientX-lastTapX,dty=t.clientY-lastTapY;
        if(now-lastTapTime<320&&dtx*dtx+dty*dty<55*55)applyZoomDelta(-120);
      } else if(touches.length===2){
        e.preventDefault();
        pinchActive=true;
        const dx=touches[0].clientX-touches[1].clientX,dy=touches[0].clientY-touches[1].clientY;
        pinchDist0=Math.sqrt(dx*dx+dy*dy);pinchZoom0=zoomTargetRef.current;
        touchDrag.active=false;
        pinchStateRef.current={active:true,dist0:pinchDist0,zoom0:pinchZoom0};
      }
    };

    const onTouchMove=(e:TouchEvent)=>{
      const touches=e.touches;
      if(touches.length===1&&touchDrag.active){
        e.preventDefault();
        const t=touches[0];
        if(touchGrabVec){
          const rect2=canvas.getBoundingClientRect();const W2=canvas.clientWidth,H2=canvas.clientHeight;const R2=Math.min(W2,H2)*0.35*zoomRef.current;
          const nv=arcballVec(t.clientX-rect2.left,t.clientY-rect2.top,W2/2,H2/2,R2);
          const q=quatFromTo(touchGrabVec,nv);
          rotMatRef.current=mat3Ortho(mat3Premul(matFromQuat(q),rotMatRef.current));
          touchGrabVec=nv;
        }
        const dx=t.clientX-touchDrag.lx,dy=t.clientY-touchDrag.ly;
        touchDrag.lx=t.clientX;touchDrag.ly=t.clientY;
        if(Math.abs(dx)>3||Math.abs(dy)>3)touchDrag.moved=true;
        hoveredRef.current=null;
        dirtyRef.current=true;
        // Update hoveredSubgenre state (clear on drag)
        if(hoveredSubgRef.current!==null){hoveredSubgRef.current=null;setHoveredSubgenre(null);}
        if(selectedRef.current!==null&&zoomRef.current>=1.1&&regionPolesRef.current.length>0){
          const se=regionPolesRef.current.find(r=>r.name===selectedRef.current);
          if(se){const[px,py,pz]=se.pole;const[,,,,,,sm6,sm7,sm8]=rotMatRef.current;if(sm6*px+sm7*py+sm8*pz<0){autoSelectedRef.current=false;selectedSubgenreRef.current=null;setSelectedSubgenre(null);zoomSubgenreRef.current=null;setZoomSubgenre(null);setSelected(null);}}
        }
      } else if(touches.length===2&&pinchActive){
        e.preventDefault();
        const dx=touches[0].clientX-touches[1].clientX,dy=touches[0].clientY-touches[1].clientY;
        const newDist=Math.sqrt(dx*dx+dy*dy);
        const newZoom=Math.max(MIN_ZOOM,Math.min(MAX_ZOOM,pinchZoom0*(newDist/pinchDist0)));
        // Write both so there's no lerp lag during pinch
        zoomTargetRef.current=newZoom;zoomRef.current=newZoom;dirtyRef.current=true;
        if(newZoom>=1.2&&selectedRef.current===null&&regionPolesRef.current.length>0){
          const[,,,,,,pm6,pm7,pm8]=rotMatRef.current;let bn=regionPolesRef.current[0].name,bz=-Infinity;
          for(const{name,pole:[px,py,pz]} of regionPolesRef.current){const z2=pm6*px+pm7*py+pm8*pz;if(z2>bz){bz=z2;bn=name;}}
          autoSelectedRef.current=true;setSelected(bn);
        }
        if(newZoom<2.0){if(zoomSubgenreRef.current!==null){zoomSubgenreRef.current=null;setZoomSubgenre(null);}if(selectedSubgenreRef.current!==null){selectedSubgenreRef.current=null;setSelectedSubgenre(null);}}
        if(newZoom<=MIN_ZOOM+0.1&&selectedRef.current!==null){autoSelectedRef.current=false;selectedSubgenreRef.current=null;setSelectedSubgenre(null);zoomSubgenreRef.current=null;setZoomSubgenre(null);setSelected(null);}
      }
    };

    const onTouchEnd=(e:TouchEvent)=>{
      const remaining=e.touches.length,wasPinching=pinchActive,wasDragging=touchDrag.active,wasMoved=touchDrag.moved;
      if(remaining===0){
        if(wasPinching)snapZoom=true;
        pinchActive=false;pinchStateRef.current.active=false;touchDrag.active=false;
        if(!wasPinching&&wasDragging&&!wasMoved){
          const ct=e.changedTouches[0];
          const rect3=canvas.getBoundingClientRect();const mx3=ct.clientX-rect3.left,my3=ct.clientY-rect3.top;
          lastTapTime=performance.now();lastTapX=ct.clientX;lastTapY=ct.clientY;
          // Label hit test with enlarged tap target
          for(const h of labelHitsRef.current){
            const E=10;
            if(mx3>=h.x1-E&&mx3<=h.x2+E&&my3>=h.y1-E&&my3<=h.y2+E){
              if(h.subgenre){
                const next=selectedSubgenreRef.current===h.subgenre?null:h.subgenre;
                selectedSubgenreRef.current=next;setSelectedSubgenre(next);
                dirtyRef.current=true;
                console.log("[subgenre-click] mobile label path", {clickedSubgenre:h.subgenre,highlightedSubgenre:next,fetchSubgenre:next,panelTitleSubgenre:next});
              }
              else{const isDe=selectedRef.current===h.name;autoSelectedRef.current=false;selectedSubgenreRef.current=null;setSelectedSubgenre(null);zoomSubgenreRef.current=null;setZoomSubgenre(null);setSelected(prev=>prev===h.name?null:h.name);if(!isDe)zoomTargetRef.current=Math.max(zoomTargetRef.current,2.5);}
              return;
            }
          }
          // Sphere hit test
          const W3=canvas.clientWidth,H3=canvas.clientHeight,R3=Math.min(W3,H3)*0.35*zoomRef.current;
          const nx3=(mx3-W3/2)/R3,ny3=(my3-H3/2)/R3;
          if(nx3*nx3+ny3*ny3>1.0){autoSelectedRef.current=false;selectedSubgenreRef.current=null;setSelectedSubgenre(null);zoomSubgenreRef.current=null;setZoomSubgenre(null);setSelected(null);}
          else {
            const nz3=Math.sqrt(Math.max(0,1-nx3*nx3-ny3*ny3));
            const[tm0,tm1,tm2,tm3,tm4,tm5,tm6,tm7,tm8]=rotMatRef.current;
            const x_w=tm0*nx3+tm3*ny3+tm6*nz3,y_w=tm1*nx3+tm4*ny3+tm7*nz3,z_w=tm2*nx3+tm5*ny3+tm8*nz3;
            const fCT=faceCentsRef.current,fRT=faceRegionRef.current;
            let bestTName: string;
            if(fCT.length>0&&fRT.length>0){let bi=0,bd=-Infinity;for(let i=0;i<fCT.length;i++){const d=fCT[i][0]*x_w+fCT[i][1]*y_w+fCT[i][2]*z_w;if(d>bd){bd=d;bi=i;}}bestTName=regionPolesRef.current[fRT[bi]]?.name??regionPolesRef.current[0].name;}
            else{let bt=regionPolesRef.current[0],bdot=-Infinity;for(const rd of regionPolesRef.current){const d=rd.pole[0]*x_w+rd.pole[1]*y_w+rd.pole[2]*z_w;if(d>bdot){bdot=d;bt=rd;}}bestTName=bt.name;}
            if(selectedRef.current!==null&&zoomRef.current>=2.0&&bestTName===selectedRef.current&&subPolesRef.current.length>0){
              const sft=[...subRegionRef.current.keys()];let bsf=sft[0]??-1,bsd=-Infinity;for(const fi of sft){const c=fCT[fi];if(!c)continue;const d=c[0]*x_w+c[1]*y_w+c[2]*z_w;if(d>bsd){bsd=d;bsf=fi;}}
              const si=subRegionRef.current.get(bsf)??0,sn=activeSubsRef.current[si]?.name??subPolesRef.current[0]?.name??"";
              const next=selectedSubgenreRef.current===sn?null:sn;
              selectedSubgenreRef.current=next;setSelectedSubgenre(next);
              dirtyRef.current=true;
              console.log("[subgenre-click] mobile polygon path", {clickedSubgenre:sn,highlightedSubgenre:next,fetchSubgenre:next,panelTitleSubgenre:next});
            } else {
              const isDe=selectedRef.current===bestTName;autoSelectedRef.current=false;selectedSubgenreRef.current=null;setSelectedSubgenre(null);zoomSubgenreRef.current=null;setZoomSubgenre(null);setSelected(prev=>prev===bestTName?null:bestTName);
              if(!isDe)zoomTargetRef.current=Math.max(zoomTargetRef.current,2.5);
            }
          }
        }
      } else if(remaining===1&&wasPinching){
        pinchActive=false;pinchStateRef.current.active=false;snapZoom=true;
        const t=e.touches[0];touchDrag={active:true,lx:t.clientX,ly:t.clientY,moved:false};
        const rect2=canvas.getBoundingClientRect();const W2=canvas.clientWidth,H2=canvas.clientHeight;const R2=Math.min(W2,H2)*0.35*zoomRef.current;
        touchGrabVec=arcballVec(t.clientX-rect2.left,t.clientY-rect2.top,W2/2,H2/2,R2);
      }
    };

    const onTouchCancel=()=>{touchDrag.active=false;touchGrabVec=null;pinchActive=false;pinchStateRef.current.active=false;};

    canvas.addEventListener("touchstart",  onTouchStart,  { passive: false });
    canvas.addEventListener("touchmove",   onTouchMove,   { passive: false });
    canvas.addEventListener("touchend",    onTouchEnd,    { passive: false });
    canvas.addEventListener("touchcancel", onTouchCancel, { passive: true  });

    function animate() {
      const zoomDiff = Math.abs(zoomRef.current - zoomTargetRef.current);
      const stillLerping = zoomDiff > 0.001;
      if (dirtyRef.current || stillLerping || dragRef.current.active) {
        const drew = drawFrame();
        if (drew && !stillLerping && !dragRef.current.active) {
          dirtyRef.current = false;
        }
      }
      // Drive zoomAbove2 state from RAF (replaces setInterval poller)
      const above = zoomRef.current >= 2.0;
      if (above !== zoomAbove2Ref.current) {
        zoomAbove2Ref.current = above;
        setZoomAbove2(above);
      }
      rafRef.current = requestAnimationFrame(animate);
    }
    rafRef.current = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(rafRef.current);
      ro.disconnect();
      canvas.removeEventListener("wheel",          onWheel);
      canvas.removeEventListener("gesturestart",   onGestureStart);
      canvas.removeEventListener("gesturechange",  onGestureChange);
      canvas.removeEventListener("gestureend",     onGestureEnd);
      canvas.removeEventListener("touchstart",     onTouchStart);
      canvas.removeEventListener("touchmove",      onTouchMove);
      canvas.removeEventListener("touchend",       onTouchEnd);
      canvas.removeEventListener("touchcancel",    onTouchCancel);
    };
  }, [worlds, loading]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Subgenre Voronoi — recomputes when selected genre, subgenres, OR worlds change ──
  //
  // `worlds` is included in deps even though the body reads geoRef (a ref, not state).
  // Reason: geoRef.current is set by the canvas effect (deps=[worlds,loading]) which
  // runs EARLIER in the file.  When a Venn back-restore mounts this component and
  // setSelected() fires before loadWorld() finishes, subgenres may arrive while
  // geoRef is still null — the guard exits early and subRegionRef stays empty.
  // Adding `worlds` ensures this effect re-fires when worlds (and therefore geoRef)
  // becomes available, regardless of which API call finishes first.
  // React runs effects in declaration order, so the canvas effect always sets
  // geoRef before this effect reads it for the same worlds state-update.
  useEffect(() => {
    const geo = geoRef.current;
    // Clear sub-voronoi state
    subRegionRef.current = new Map();
    activeSubsRef.current = [];
    subPolesRef.current = [];

    if (!geo || selected === null || subgenres.length === 0) {
      dirtyRef.current = true;
      return;
    }

    const { faces, cents, adj, names, region } = geo;
    const selIdx = names.indexOf(selected);
    if (selIdx >= 0) {
      const gfi = faces.map((_,i)=>i).filter(i=>region[i]===selIdx);
      if (gfi.length > 0) {
        const maxSubs = Math.max(1, Math.floor(gfi.length/3));
        const actSubs = subgenres.slice(0, maxSubs);
        activeSubsRef.current = actSubs;
        const n = actSubs.length;
        const gfiSet = new Set(gfi);
        const subAdj = new Map<number,number[]>(gfi.map(fi=>[fi,adj[fi].filter(ni=>gfiSet.has(ni))]));
        const subTotal = actSubs.reduce((s,sg)=>s+sg.count,0)||1;
        const targets  = actSubs.map(sg=>Math.max(1,Math.round((sg.count/subTotal)*gfi.length)));
        const tSum = targets.reduce((s,t)=>s+t,0); let surplus=gfi.length-tSum;
        if(surplus>0){for(let i=0;surplus>0;i=(i+1)%n){targets[i]++;surplus--;}}
        else if(surplus<0){for(let i=n-1;surplus<0;i=((i-1)+n)%n){if(targets[i]>1){targets[i]--;surplus++;}}}
        let psx=0,psy=0,psz=0;
        for(const fi of gfi){psx+=cents[fi][0];psy+=cents[fi][1];psz+=cents[fi][2];}
        psx/=gfi.length;psy/=gfi.length;psz/=gfi.length;
        let firstSeed=gfi[0],bestCentDot=-Infinity;
        for(const fi of gfi){const d=cents[fi][0]*psx+cents[fi][1]*psy+cents[fi][2]*psz;if(d>bestCentDot){bestCentDot=d;firstSeed=fi;}}
        const seedFaces=[firstSeed];
        const minDist=new Float32Array(gfi.length).fill(Infinity);
        const updateDists=(sf:number)=>{const[sx,sy,sz]=cents[sf];for(let j=0;j<gfi.length;j++){const[fx,fy,fz]=cents[gfi[j]];const dot=Math.min(1,Math.max(-1,fx*sx+fy*sy+fz*sz));const d=Math.acos(dot);if(d<minDist[j])minDist[j]=d;}};
        updateDists(firstSeed);
        for(let s=1;s<n;s++){let fj=0;for(let j=1;j<gfi.length;j++){if(minDist[j]>minDist[fj])fj=j;}seedFaces.push(gfi[fj]);updateDists(gfi[fj]);}
        const assignment=new Map<number,number>(),frontiers: number[][]=Array.from({length:n},()=>[]);
        const rCounts=new Array<number>(n).fill(0);
        for(let i=0;i<n;i++){assignment.set(seedFaces[i],i);frontiers[i].push(seedFaces[i]);rCounts[i]=1;}
        let totalA=n;
        while(totalA<gfi.length){let grew=false;for(let i=0;i<n;i++){if(rCounts[i]>=targets[i]||!frontiers[i].length)continue;let found=false;while(frontiers[i].length>0&&!found){const fi2=frontiers[i][0];let cl=false;for(const ni of(subAdj.get(fi2)??[])){if(!assignment.has(ni)){assignment.set(ni,i);rCounts[i]++;totalA++;frontiers[i].push(ni);cl=true;found=true;grew=true;break;}}if(!cl)frontiers[i].shift();}}if(!grew)break;}
        let mopping=true;while(mopping){mopping=false;for(const fi of gfi){if(assignment.has(fi))continue;for(const ni of(subAdj.get(fi)??[])){if(assignment.has(ni)){assignment.set(fi,assignment.get(ni)!);mopping=true;break;}}}}
        for(const fi of gfi){if(!assignment.has(fi))assignment.set(fi,0);}
        subRegionRef.current=assignment;
        const pAcc: V3[]=Array.from({length:n},()=>[0,0,0] as V3);const pCnt=new Int32Array(n);
        for(const[fi2,si] of assignment){pAcc[si][0]+=cents[fi2][0];pAcc[si][1]+=cents[fi2][1];pAcc[si][2]+=cents[fi2][2];pCnt[si]++;}
        subPolesRef.current=actSubs.map((sub,i)=>({name:sub.name,pole:pCnt[i]>0?norm3([pAcc[i][0]/pCnt[i],pAcc[i][1]/pCnt[i],pAcc[i][2]/pCnt[i]]):cents[seedFaces[i]]}));
      }
    }

    // ── Venn / URL-param subgenre centering ──────────────────────────────────
    // If the page was opened with ?subgenre=... rotate the sphere so that
    // subgenre region faces the camera.  Runs once per navigation after the
    // subgenre poles have just been computed above.
    if (urlSubgenreParamRef.current && !urlSubgenreCenteredRef.current && subPolesRef.current.length > 0) {
      const targetSub = urlSubgenreParamRef.current;
      const entry = subPolesRef.current.find(sp => sp.name === targetSub);
      if (entry) {
        urlSubgenreCenteredRef.current = true;
        // Rotate: bring subgenre pole to (0,0,1) — the "facing camera" direction.
        // This overrides the genre-level rotation set earlier so the view is
        // centered precisely on the subgenre region.
        const q = quatFromTo(entry.pole, [0, 0, 1] as V3);
        rotMatRef.current = mat3Ortho(matFromQuat(q));
      }
    }

    dirtyRef.current = true;
  }, [selected, subgenres, worlds]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Desktop mouse handlers (arcball, same model as mobile) ────────────────

  const onMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    dragRef.current = { active: true, lx: e.clientX, ly: e.clientY, moved: false };
    const canvas = canvasRef.current; if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const W = canvas.clientWidth, H = canvas.clientHeight;
    const R = Math.min(W, H) * 0.35 * zoomRef.current;
    grabVecRef.current = arcballVec(e.clientX - rect.left, e.clientY - rect.top, W/2, H/2, R);
  };

  const onMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (dragRef.current.active && grabVecRef.current) {
      const canvas = canvasRef.current!;
      const rect = canvas.getBoundingClientRect();
      const W = canvas.clientWidth, H = canvas.clientHeight;
      const R = Math.min(W, H) * 0.35 * zoomRef.current;
      const nv = arcballVec(e.clientX - rect.left, e.clientY - rect.top, W/2, H/2, R);
      const q = quatFromTo(grabVecRef.current, nv);
      rotMatRef.current  = mat3Ortho(mat3Premul(matFromQuat(q), rotMatRef.current));
      grabVecRef.current = nv;
      dragRef.current.lx = e.clientX; dragRef.current.ly = e.clientY;
      dragRef.current.moved = true;
      hoveredRef.current = null;
      dirtyRef.current = true;
      // Update hoveredSubgenre state (clear on drag)
      if (hoveredSubgRef.current !== null) { hoveredSubgRef.current = null; setHoveredSubgenre(null); }
      if (selectedRef.current !== null && zoomRef.current >= 1.1 && regionPolesRef.current.length > 0) {
        const se = regionPolesRef.current.find(r => r.name === selectedRef.current);
        if (se) { const [px,py,pz]=se.pole; const [,,,,,,dm6,dm7,dm8]=rotMatRef.current; if(dm6*px+dm7*py+dm8*pz<0){autoSelectedRef.current=false;selectedSubgenreRef.current=null;setSelectedSubgenre(null);zoomSubgenreRef.current=null;setZoomSubgenre(null);setSelected(null);}}
      }
      return;
    }
    // Hover hit test: throttle to one per RAF
    if (!mouseMoveRafRef.current) {
      const mx = e.clientX, my = e.clientY; // capture before async
      mouseMoveRafRef.current = true;
      requestAnimationFrame(() => {
        mouseMoveRafRef.current = false;
        const canvas=canvasRef.current; if(!canvas)return;
        const rect=canvas.getBoundingClientRect();
        const lx=mx-rect.left,ly=my-rect.top;
        for(const h of labelHitsRef.current){if(lx>=h.x1&&lx<=h.x2&&ly>=h.y1&&ly<=h.y2){
          hoveredRef.current=h.subgenre?{genre:h.name,subgenre:h.subgenre}:{genre:h.name};
          // Sync hoveredSubgenre state so focusedSubgenre reflects the label under
          // the cursor, not whatever polygon body the cursor previously touched.
          // Without this, the track panel title would lag behind the visual highlight.
          const labelSub = h.subgenre ?? null;
          if (labelSub !== hoveredSubgRef.current) { hoveredSubgRef.current = labelSub; setHoveredSubgenre(labelSub); }
          dirtyRef.current=true;return;
        }}
        // Sphere hit test
        const W=canvas.clientWidth,H=canvas.clientHeight,R=Math.min(W,H)*0.35*zoomRef.current;
        const nx=(lx-W/2)/R,ny=(ly-H/2)/R;
        if(nx*nx+ny*ny>1){hoveredRef.current=null;dirtyRef.current=true;return;}
        const nz=Math.sqrt(Math.max(0,1-nx*nx-ny*ny));
        const[hm0,hm1,hm2,hm3,hm4,hm5,hm6,hm7,hm8]=rotMatRef.current;
        const x_w=hm0*nx+hm3*ny+hm6*nz,y_w=hm1*nx+hm4*ny+hm7*nz,z_w=hm2*nx+hm5*ny+hm8*nz;
        const fC=faceCentsRef.current,fR=faceRegionRef.current;
        let genreName: string;
        if(fC.length>0&&fR.length>0){let bi=0,bd=-Infinity;for(let i=0;i<fC.length;i++){const d=fC[i][0]*x_w+fC[i][1]*y_w+fC[i][2]*z_w;if(d>bd){bd=d;bi=i;}}genreName=regionPolesRef.current[fR[bi]]?.name??"";}
        else{let bt=regionPolesRef.current[0],bdot=-Infinity;for(const rd of regionPolesRef.current){const d=rd.pole[0]*x_w+rd.pole[1]*y_w+rd.pole[2]*z_w;if(d>bdot){bdot=d;bt=rd;}}genreName=bt.name;}
        if(!genreName){hoveredRef.current=null;dirtyRef.current=true;return;}
        if(selectedRef.current!==null&&zoomRef.current>=2.0&&genreName===selectedRef.current&&subPolesRef.current.length>0){
          if(nx*nx+ny*ny<=1){
            const nz2=Math.sqrt(Math.max(0,1-nx*nx-ny*ny));
            const[mm0,mm1,mm2,mm3,mm4,mm5,mm6,mm7,mm8]=rotMatRef.current;
            const x_w2=mm0*nx+mm3*ny+mm6*nz2,y_w2=mm1*nx+mm4*ny+mm7*nz2,z_w2=mm2*nx+mm5*ny+mm8*nz2;
            const sft=[...subRegionRef.current.keys()];let bsf=sft[0]??-1,bsd=-Infinity;
            for(const fi of sft){const c=fC[fi];if(!c)continue;const d=c[0]*x_w2+c[1]*y_w2+c[2]*z_w2;if(d>bsd){bsd=d;bsf=fi;}}
            const si=subRegionRef.current.get(bsf)??0;
            const sn=activeSubsRef.current[si]?.name??subPolesRef.current[0]?.name??"";
            hoveredRef.current={genre:genreName,subgenre:sn};
            // Drive hoveredSubgenre state directly
            const ns = zoomRef.current >= 2.0 ? sn : null;
            if (ns !== hoveredSubgRef.current) { hoveredSubgRef.current = ns; setHoveredSubgenre(ns); }
            dirtyRef.current=true;return;
          }
        }
        hoveredRef.current={genre:genreName};
        // Clear subgenre hover if not zoomed enough
        const ns2 = null;
        if (ns2 !== hoveredSubgRef.current) { hoveredSubgRef.current = ns2; setHoveredSubgenre(ns2); }
        dirtyRef.current=true;
      });
    }
  };

  const stopDrag   = () => { dragRef.current.active = false; };
  const onMouseLeave = () => {
    dragRef.current.active = false;
    hoveredRef.current     = null;
    dirtyRef.current       = true; // redraw to erase hover highlight immediately
    // Also clear hoveredSubgenre state so it can't influence anything on re-enter
    if (hoveredSubgRef.current !== null) { hoveredSubgRef.current = null; setHoveredSubgenre(null); }
  };

  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (dragRef.current.moved) return;
    const canvas=canvasRef.current!;const rect=canvas.getBoundingClientRect();
    const mx=e.clientX-rect.left,my=e.clientY-rect.top;
    for(const h of labelHitsRef.current){if(mx>=h.x1&&mx<=h.x2&&my>=h.y1&&my<=h.y2){
      if(h.subgenre){
        const next=selectedSubgenreRef.current===h.subgenre?null:h.subgenre;
        selectedSubgenreRef.current=next;
        setSelectedSubgenre(next);
        // Clear stale hover so focusedSubgenre = selectedSubgenre immediately.
        // (Hover can point to a different polygon than the label drawn on top of it.)
        hoveredSubgRef.current=null;
        setHoveredSubgenre(null);
        console.log("[subgenre-click] label path", {
          clickedSubgenre:  h.subgenre,
          highlightedSubgenre: next,   // = selectedSubgenreRef after update
          fetchSubgenre:    next,       // focusedSubgenre will resolve to this
          panelTitleSubgenre: next,
        });
      }else{
        autoSelectedRef.current=false;selectedSubgenreRef.current=null;setSelectedSubgenre(null);
        hoveredSubgRef.current=null;setHoveredSubgenre(null);
        zoomSubgenreRef.current=null;setZoomSubgenre(null);setSelected(p=>p===h.name?null:h.name);
      }
      return;
    }}
    const W=canvas.clientWidth,H=canvas.clientHeight,R=Math.min(W,H)*0.35*zoomRef.current;
    const nx=(mx-W/2)/R,ny=(my-H/2)/R;
    if(nx*nx+ny*ny>1){autoSelectedRef.current=false;selectedSubgenreRef.current=null;setSelectedSubgenre(null);zoomSubgenreRef.current=null;setZoomSubgenre(null);setSelected(null);return;}
    const nz=Math.sqrt(Math.max(0,1-nx*nx-ny*ny));
    const[cm0,cm1,cm2,cm3,cm4,cm5,cm6,cm7,cm8]=rotMatRef.current;
    const x_w=cm0*nx+cm3*ny+cm6*nz,y_w=cm1*nx+cm4*ny+cm7*nz,z_w=cm2*nx+cm5*ny+cm8*nz;
    const fC=faceCentsRef.current,fR=faceRegionRef.current;
    let bestName: string;
    if(fC.length>0&&fR.length>0){let bi=0,bd=-Infinity;for(let i=0;i<fC.length;i++){const d=fC[i][0]*x_w+fC[i][1]*y_w+fC[i][2]*z_w;if(d>bd){bd=d;bi=i;}}bestName=regionPolesRef.current[fR[bi]]?.name??regionPolesRef.current[0].name;}
    else{let bt=regionPolesRef.current[0],bdot=-Infinity;for(const rd of regionPolesRef.current){const d=rd.pole[0]*x_w+rd.pole[1]*y_w+rd.pole[2]*z_w;if(d>bdot){bdot=d;bt=rd;}}bestName=bt.name;}
    if(selectedRef.current!==null&&zoomRef.current>=2.0&&bestName===selectedRef.current&&subPolesRef.current.length>0){
      const sft=[...subRegionRef.current.keys()];let bsf=sft[0]??-1,bsd=-Infinity;for(const fi of sft){const c=fC[fi];if(!c)continue;const d=c[0]*x_w+c[1]*y_w+c[2]*z_w;if(d>bsd){bsd=d;bsf=fi;}}
      const si=subRegionRef.current.get(bsf)??0,sn=activeSubsRef.current[si]?.name??subPolesRef.current[0]?.name??"";
      const next=selectedSubgenreRef.current===sn?null:sn;
      selectedSubgenreRef.current=next;
      setSelectedSubgenre(next);
      // Hovering over the polygon body already set hoveredSubgenre to sn via onMouseMove.
      // After the click, both selectedSubgenre=next and hoveredSubgenre=sn should agree —
      // but clear hover so focusedSubgenre resolves to selectedSubgenre unambiguously.
      hoveredSubgRef.current=null;
      setHoveredSubgenre(null);
      console.log("[subgenre-click] polygon path", {
        clickedSubgenre:    sn,
        highlightedSubgenre: next,
        fetchSubgenre:      next,
        panelTitleSubgenre: next,
      });
      return;
    }
    autoSelectedRef.current=false;selectedSubgenreRef.current=null;setSelectedSubgenre(null);zoomSubgenreRef.current=null;setZoomSubgenre(null);
    setSelected(p=>p===bestName?null:bestName);
  };

  // ── Derived render values (must stay above any early return — hooks rule) ──
  // useMemo is a hook and cannot be called after a conditional return.
  // All derived constants that feed into the memo are kept here too so they
  // are computed in the same order on every render.

  const selectedColor   = selected ? (COLORS[selected] ?? "#ffffff") : "#ffffff";
  const [sr, sg, sb]    = selected ? hexRgb(COLORS[selected] ?? "#ffffff") : [255, 255, 255];
  // focusedSubgenre is ONLY driven by clicked/locked state — never by hover.
  // hoveredSubgenre drives canvas visual highlighting (via hoveredRef.current in
  // the RAF draw loop) but must never affect the side-panel title or tracklist.
  // Hovering while moving toward the side panel would otherwise silently swap
  // the displayed genre/subgenre out from under the user's clicked selection.
  const focusedSubgenre = selectedSubgenre;
  const displayedTracks = focusedSubgenre
    ? tracks.filter(t => t.blueprintSubgenre === focusedSubgenre)
    : tracks;

  // Use socialUsers.length as authoritative count — always equals socialCount from the API.
  const tallyCount = (t: TrackItem) => t.socialUsers?.length ?? t.socialCount ?? 0;

  // ── Canonical track sort — single source of truth for desktop + mobile ────
  // Both platforms call this exact function through the useMemo below.
  // Sort priority (highest to lowest):
  //   1. Unheard mode  — isUnheardForSelectedUser === true first
  //                      false second, undefined last (no spotifyId)
  //   2. Live events   — tracks with a concert first (if liveMode)
  //   3. Social sort   — by socialCount desc (if socialSort)
  //   4. Default       — original artist/name order from API
  // Within each tier the secondary tiers still apply for further ordering.
  const visibleTrackRows = useMemo(() => {
    const result = getDisplayTracks(displayedTracks, {
      unheardMode, liveMode, socialSort, liveEventMap,
      tallyCount,
    });

    // ── Dev-only debug log ───────────────────────────────────────────────────
    if (process.env.NODE_ENV === "development" && unheardMode) {
      const platform = typeof window !== "undefined" && window.innerWidth <= 768 ? "mobile" : "desktop";
      console.log(`[visibleTrackRows] platform=${platform}`, {
        genre:             selected,
        subgenre:          focusedSubgenre,
        substituteUserId:  substituteProfileRef.current?.userId,
        unheardMode,
        socialSort,
        liveMode,
        trackCount:        result.length,
        first5:            result.slice(0, 5).map(t => ({
          name:                  t.name,
          isUnheardForSelectedUser: t.isUnheardForSelectedUser,
        })),
      });
    }

    return result;
  }, [displayedTracks, liveMode, socialSort, unheardMode, liveEventMap]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Live-events background fetch ─────────────────────────────────────────
  // Silently fetches live event data whenever the displayed track list changes
  // so ticket icons appear without the user having to click the button.
  // liveEventMap is a session cache — each artist is queried at most once.
  // This effect MUST stay above the if (loading) early return (hooks ordering).
  useEffect(() => {
    if (displayedTracks.length === 0) return;
    const needed = [...new Set(displayedTracks.map(t => normalizeArtist(t.artist)))]
      .filter(a => !(a in liveEventMap));
    if (needed.length === 0) return;
    const url = `/api/events/live?artists=${encodeURIComponent(needed.join(","))}`;
    fetch(url)
      .then(r => r.ok ? r.json() as Promise<Record<string, LiveEvent | null>> : null)
      .then(data => { if (data) setLiveEventMap(prev => ({ ...prev, ...data })); })
      .catch(() => {});
  }, [displayedTracks]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Render ─────────────────────────────────────────────────────────────────
  // Early return placed AFTER all hooks (including useMemo above) so that
  // hooks are always called in the same order regardless of loading state.
  if (loading) {
    return (
      <main className="min-h-screen bg-black text-white flex items-center justify-center">
        <p className="text-xl">Loading your Music World...</p>
      </main>
    );
  }

  // ── Live-events toggle handler ────────────────────────────────────────────
  // Mode OFF → ON : fetch uncached artists, merge into liveEventMap.
  // Mode ON  → OFF: clear flag; map kept as session cache.
  const handleLiveToggle = async () => {
    if (liveMode) { setLiveMode(false); return; }

    setLiveMode(true);

    const allArtists = [...new Set(displayedTracks.map(t => normalizeArtist(t.artist)))];
    const needed     = allArtists.filter(a => !(a in liveEventMap));
    if (needed.length === 0) return;

    setLiveLoading(true);
    try {
      const url = `/api/events/live?artists=${encodeURIComponent(needed.join(","))}`;
      const res = await fetch(url);
      if (!res.ok) return;
      const data: Record<string, LiveEvent | null> = await res.json();
      setLiveEventMap(prev => ({ ...prev, ...data }));
    } catch {
      // ignore
    } finally {
      setLiveLoading(false);
    }
  };

  // ── Playlist push handler ─────────────────────────────────────────────────
  // Unique key for the current view — used to track which playlists have
  // already been created this session.
  // Format: {worldType}:{ownerId}:{genre}:{subgenre|"all"}
  // Examples: "user:abc123:Rap / Hip-Hop:all"
  //           "friends:friends:R&B / Soul / Funk:Neo Soul"
  const playlistKey: string | null = selected
    ? [
        friendsWorld ? "friends" : "user",
        friendsWorld ? "friends" : (userId ?? sessionUserId ?? "me"),
        selected,
        focusedSubgenre ?? "all",
      ].join(":")
    : null;

  // Venn href — only shown on individual worlds (not the Friends aggregate world)
  const vennHref: string | null = !friendsWorld && selected
    ? focusedSubgenre
      ? `/midvale/friends?genre=${encodeURIComponent(selected)}&subgenre=${encodeURIComponent(focusedSubgenre)}`
      : `/midvale/friends?genre=${encodeURIComponent(selected)}`
    : null;

  // Called by VennButton just before navigating to the Friends World.
  //
  // SUBSTITUTE PROFILE PRESERVATION RULE:
  //   If the user already has a viewing-as profile selected, we must NOT
  //   overwrite it with the source world owner.  The user's explicit lens
  //   should survive the round-trip to Friends World and back.
  //
  //   Only when no profile is selected do we fall back to the world owner
  //   as a sensible default so the Unheard button works on first visit.
  //
  //   The source world owner is always stored separately as
  //   blueprint:vennSourceOwner so Friends World has context about where
  //   navigation came from, independent of the viewing-as lens.
  const handleVennNavigate = (): void => {
    const subId   = userId ?? sessionUserId;
    const subName = userName ?? "";
    if (!subId) return;
    const sourceOwner = { userId: subId, userName: subName };
    try {
      // Read current substitute — may have been explicitly set by the user.
      let existing: { userId: string; userName: string } | null = null;
      try {
        const raw = sessionStorage.getItem("blueprint:substituteProfile");
        existing = raw ? JSON.parse(raw) : null;
      } catch { /* ignore parse errors */ }

      if (!existing) {
        // No explicit viewing-as profile — use source world owner as default
        // so the Unheard button works on first arrival in Friends World.
        sessionStorage.setItem("blueprint:substituteProfile", JSON.stringify(sourceOwner));
        // Dispatch so any co-mounted WorldSphere picks the change up immediately.
        window.dispatchEvent(
          new CustomEvent("blueprint:substituteChange", { detail: sourceOwner }),
        );
      }
      // else: user has an explicit profile selected — leave it untouched.
      // Friends World will use it as-is; Unheard will compare against it.

      // Always record the source world owner separately.  Friends World uses
      // this for context (e.g. centering) without conflating it with the
      // user's chosen viewing-as lens.
      sessionStorage.setItem("blueprint:vennSourceOwner", JSON.stringify(sourceOwner));

      // Signal Friends World to auto-enable Unheard mode on arrival.
      sessionStorage.setItem("blueprint:autoEnableUnheard", "true");

      // Store full origin state so the Friends World back button can return
      // the user here with camera position, genre, and toggles intact.
      const originRoute = typeof window !== "undefined" ? window.location.pathname : "/world";
      // originKind unambiguously marks homepage vs individual so the back button
      // never falls back to a userId-derived route.
      const originKind: "homepage" | "individual" =
        (originRoute === "/world" || originRoute === "/") ? "homepage" : "individual";
      const originState = {
        originKind,
        route:      originRoute,
        genre:      selected,
        subgenre:   selectedSubgenre,
        zoom:       zoomRef.current,
        rotMat:     Array.from(rotMatRef.current),
        socialSort,
        liveMode,
        unheardMode,
      };
      console.log("[Venn] storing origin state:", originState);
      sessionStorage.setItem("blueprint:vennOriginState", JSON.stringify(originState));
    } catch { /* sessionStorage unavailable — degrade gracefully */ }
  };

  // Venn enabled — true only when the current genre (and subgenre, if focused)
  // actually exists in the Friends aggregate world.
  // Remains false while friendsGenres is still loading (null).
  const vennEnabled: boolean = (() => {
    if (!selected || friendsWorld) return false;
    if (friendsGenres === null) return false;                         // loading
    if (!(selected in friendsGenres)) return false;                  // genre absent
    if (!focusedSubgenre) return true;                               // genre present, no subgenre filter
    const subs = friendsSubgenres[selected];
    if (!subs) return false;                                         // subgenres not yet fetched
    return subs.includes(focusedSubgenre);                           // subgenre present?
  })();

  const handlePlaylistPush = async () => {
    if (!selected || playlistLoading) return;

    // ── Diagnostic ──────────────────────────────────────────────────────────
    console.log("[playlist-push] invoked", {
      surface:         isMobile ? "mobile" : "desktop",
      sessionStatus,
      sessionUserId,
      hasCookie:       document.cookie.length > 0,
      cookieSnippet:   document.cookie.slice(0, 120),
      location:        window.location.href,
      selected,
      focusedSubgenre,
      friendsWorld,
    });

    setPlaylistLoading(true);
    setPlaylistMsg(null);
    setPlaylistAuthError(null);

    // Pre-flight: skip fetch if we already know the user isn't signed in.
    if (sessionStatus === "unauthenticated") {
      setPlaylistLoading(false);
      setPlaylistAuthError("signin");
      return;
    }

    try {
      // Build the ordered Spotify URI list from the exact array rendered in the
      // Track tab.  Tracks missing a spotifyId are filtered out here; the server
      // also guards against them in its dedup pass.
      const orderedSpotifyIds = visibleTrackRows
        .map(t => t.spotifyId)
        .filter((id): id is string => !!id);

      const body: {
        worldType: "user" | "friends";
        userId?:   string;
        genre:     string;
        subgenre?: string;
        trackIds?: string[];
      } = {
        worldType: friendsWorld ? "friends" : "user",
        genre:     selected,
        ...(userId          ? { userId }                        : {}),
        ...(focusedSubgenre ? { subgenre: focusedSubgenre }     : {}),
        // Always pass the client-side ordered IDs so the server uses the exact
        // order visible in the Track tab — including friends world, where social,
        // live, and unheard sorting must be preserved.
        ...(orderedSpotifyIds.length > 0 ? { trackIds: orderedSpotifyIds } : {}),
      };

      const res  = await fetch("/api/spotify/playlist-push", {
        method:      "POST",
        credentials: "include",
        headers:     { "Content-Type": "application/json" },
        body:        JSON.stringify(body),
      });
      const data = await res.json();

      console.log("[playlist-push] response", { status: res.status, data });

      if (!res.ok) {
        if (res.status === 401 || data.error === "Not authenticated" || data.error === "not_authenticated") {
          setPlaylistAuthError("signin");
        } else if (res.status === 403 || data.error === "missing_scope") {
          setPlaylistAuthError("reconnect");
        } else {
          setPlaylistMsg(data.message ?? data.error ?? "Failed to create playlist.");
        }
        return;
      }

      // Success — open playlist and mark key as created for this session
      window.open(data.playlistUrl, "_blank", "noopener,noreferrer");
      if (playlistKey) {
        setCreatedPlaylistKeys(prev => {
          const next = new Set(prev);
          next.add(playlistKey);
          try {
            sessionStorage.setItem("blueprint:createdPlaylists", JSON.stringify([...next]));
          } catch { /* sessionStorage unavailable — degrade gracefully */ }
          return next;
        });
      }
    } catch (err) {
      console.error("[playlist-push] fetch failed:", err);
      setPlaylistMsg("Failed to create playlist.");
    } finally {
      setPlaylistLoading(false);
    }
  };

  return (
    <main className="h-screen bg-black text-white flex flex-col overflow-hidden">

      {/* ── Back button — always-fixed, above every layer ────────────────────────
          Must NOT live inside the canvas div or any flex/overflow container.
          position:fixed anchors it to the viewport regardless of:
            - selected genre / subgenre
            - zoom level
            - mobile sheet snap state
            - canvas transforms
          z-index 210 > zoom pill (120) > mobile sheet (100).
          Uses router.push (not Link href) so route is resolved at click time —
          never inferred from userId at mount time. */}
      {backHref && (
        <button
          aria-label={vennOriginRoute ? "Back to previous world" : "Back to Friends"}
          onClick={() => {
            if (!friendsWorld) {
              // Non-friends worlds have a static backHref — just navigate.
              router.push(backHref);
              return;
            }
            // Friends World: resolve exact back target from sessionStorage at
            // click time so stale mount-time state can never win.
            try {
              const raw = sessionStorage.getItem("blueprint:vennOriginState");
              console.log("[Friends back] clicked — raw vennOriginState:", raw);

              if (raw) {
                const state = JSON.parse(raw) as {
                  originKind?: string;
                  route?: string;
                  [key: string]: unknown;
                };
                console.log("[Friends back] originKind:", state.originKind, "route:", state.route);

                // Transfer to pendingRestore so the destination world can
                // recover its camera + genre + toggle state.
                sessionStorage.setItem("blueprint:pendingRestore", raw);
                sessionStorage.removeItem("blueprint:vennOriginState");

                // Determine target route.
                // homepage origins must NEVER map to /midvale/[userId].
                // Use the exact stored route — "/" stays "/", "/world" stays "/world".
                const isHomepage =
                  state.originKind === "homepage" ||
                  state.route === "/" ||
                  state.route === "/world";
                const target = isHomepage
                  ? (state.route ?? "/")   // exact origin — "/" or "/world", never a userId path
                  : (state.route ?? backHref);

                console.log("[Friends back] pushing to:", target);
                router.push(target);
              } else {
                // No origin state — standard Friends back fallback.
                console.log("[Friends back] no origin state, pushing to:", backHref);
                router.push(backHref);
              }
            } catch {
              router.push(backHref);
            }
          }}
          style={{
            // Sits flush below the fixed Navbar (height 56) with a 12 px gap.
            // left matches the Navbar's own paddingLeft so it aligns with the
            // Blueprint wordmark above it on every viewport width.
            position:      "fixed",
            top:           "calc(56px + 12px + env(safe-area-inset-top, 0px))",
            left:          "clamp(20px, 5vw, 56px)",
            zIndex:        210,
            display:       "flex",
            alignItems:    "center",
            justifyContent:"center",
            color:         "rgba(255,255,255,0.88)",
            cursor:        "pointer",
            width:         36,
            height:        36,
            borderRadius:  "50%",
            background:    "rgba(0,0,0,0.80)",
            border:        "1px solid rgba(255,255,255,0.10)",
            backdropFilter:"blur(8px)",
            WebkitBackdropFilter: "blur(8px)",
            transition:    "background 0.15s ease",
          }}
          onMouseEnter={e => { e.currentTarget.style.background = "rgba(50,50,50,0.90)"; }}
          onMouseLeave={e => { e.currentTarget.style.background = "rgba(0,0,0,0.80)"; }}
        >
          <svg width={13} height={13} viewBox="0 0 10 10" fill="none" stroke="currentColor"
            strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <polyline points="6.5,1.5 2.5,5 6.5,8.5" />
          </svg>
        </button>
      )}

      {/* ── Utility bar ──────────────────────────────────────────────────────── */}
      <div className="flex-shrink-0 flex items-center justify-between px-6 py-2.5">
        <span className="text-xs tracking-widest uppercase text-zinc-700 font-medium select-none">
          Blueprint
        </span>
        <div className="flex items-center gap-3">
          {error && <span className="text-red-500 text-xs">{error}</span>}
          {/* Auto-sync status pill — fades in when synced, hidden otherwise */}
          {!userId && syncStatus === "synced" && (
            <span
              className="text-zinc-600 text-xs select-none"
              style={{ transition: "opacity 0.4s ease" }}
            >
              synced
            </span>
          )}
          {/* Hide sync button when viewing someone else's world */}
          {!userId && (
            <button
              onClick={refreshFromSpotify}
              disabled={refreshing || syncStatus === "syncing"}
              className="text-zinc-600 hover:text-zinc-300 disabled:opacity-40 text-xs transition-colors"
            >
              {refreshing || syncStatus === "syncing" ? "syncing…" : "sync library"}
            </button>
          )}
        </div>
      </div>

      {/* ── Body ─────────────────────────────────────────────────────────────── */}
      <div className="flex flex-1 min-h-0">

        {/* Canvas area — full width on mobile, flex-1 on desktop */}
        <div className="flex-1 relative min-w-0">
          {Object.keys(worlds).length === 0 ? (
            <div className="absolute inset-0 flex items-center justify-center">
              <p className="text-zinc-700 text-sm">Sync your library to begin</p>
            </div>
          ) : (
            <canvas
              ref={canvasRef}
              className="absolute inset-0 w-full h-full cursor-pointer"
              style={{
                display: "block",
                // Mobile: pull the sphere up by 15% — identical offset to homepage
                // so the sphere sits at the same vertical position on both pages.
                transform: isMobile ? "translateY(-15%)" : undefined,
                transition: "none",
              }}
              onMouseDown={onMouseDown}
              onMouseMove={onMouseMove}
              onMouseUp={stopDrag}
              onMouseLeave={onMouseLeave}
              onClick={handleClick}
            />
          )}

          {/* Mobile headline — "<Name>'s Music" anchored above the sphere midline.
              userName is passed from the server page (never hardcoded here).
              Rendered only when userName is provided. */}
          {isMobile && userName && (
            <div
              className="absolute z-10 flex flex-col pointer-events-none"
              style={{
                bottom:     "26%",
                left:       0,
                right:      0,
                alignItems: "center",
                textAlign:  "center",
                padding:    "0 24px",
              }}
            >
              <h1
                className="font-semibold leading-[1.06] text-white mb-3"
                style={{ letterSpacing: "-0.02em", fontSize: 19 }}
              >
                {possessiveHeadline(userName)}
              </h1>
            </div>
          )}

        </div>

        {/* ── Desktop right panel (hidden on mobile) ─────────────────────────── */}
        {!isMobile && (
          <div
            className="flex-shrink-0 flex flex-col overflow-hidden"
            style={{
              width: "42%",
              borderLeft: `1px solid rgba(${sr},${sg},${sb},0.14)`,
              background: "rgba(4,4,8,0.98)",
            }}
          >
            {selected ? (
              <>
                <div className="flex-shrink-0" style={{ height: 2, background: selectedColor, opacity: 0.85 }} />
                <div className="flex-shrink-0 px-7 pt-5 pb-4">
                  {focusedSubgenre ? (
                    <>
                      <button
                        onClick={() => { setSelectedSubgenre(null); selectedSubgenreRef.current = null; setZoomSubgenre(null); zoomSubgenreRef.current = null; }}
                        className="text-xs mb-3 flex items-center gap-1.5 transition-opacity hover:opacity-100"
                        style={{ color: `rgba(${sr},${sg},${sb},0.45)` }}
                      >← {shortLabel(selected)}</button>
                      <div className="flex items-center justify-between gap-4">
                        <h2 className="text-2xl font-bold leading-tight truncate" style={{ color: selectedColor }}>{focusedSubgenre}</h2>
                        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                          {showUnheard && <UnheardButton active={unheardMode} onClick={() => setUnheardMode(v => !v)} color={selectedColor} name={substituteProfile?.userName} />}
                          {vennHref && <VennButton href={vennHref} color={selectedColor} disabled={!vennEnabled} onBeforeNavigate={handleVennNavigate} />}
                          <BarChartButton active={socialSort} onClick={() => setSocialSort(v => !v)} color={selectedColor} />
                          <PinButton active={liveMode} loading={liveLoading} onClick={handleLiveToggle} color={selectedColor} />
                          <PlaylistButton loading={playlistLoading} success={!!(playlistKey && createdPlaylistKeys.has(playlistKey))} onClick={handlePlaylistPush} color={selectedColor} />
                          <SpotifyLogoButton track={playingTrack} />
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      <p className="text-xs tracking-widest uppercase mb-2" style={{ color: `rgba(${sr},${sg},${sb},0.38)` }}>{friendsWorld ? "Friends" : "Now exploring"}</p>
                      <div className="flex items-center justify-between gap-4">
                        <h2 className="text-2xl font-bold leading-tight truncate" style={{ color: selectedColor }}>{shortLabel(selected)}</h2>
                        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                          {showUnheard && <UnheardButton active={unheardMode} onClick={() => setUnheardMode(v => !v)} color={selectedColor} name={substituteProfile?.userName} />}
                          {vennHref && <VennButton href={vennHref} color={selectedColor} disabled={!vennEnabled} onBeforeNavigate={handleVennNavigate} />}
                          <BarChartButton active={socialSort} onClick={() => setSocialSort(v => !v)} color={selectedColor} />
                          <PinButton active={liveMode} loading={liveLoading} onClick={handleLiveToggle} color={selectedColor} />
                          <PlaylistButton loading={playlistLoading} success={!!(playlistKey && createdPlaylistKeys.has(playlistKey))} onClick={handlePlaylistPush} color={selectedColor} />
                          <SpotifyLogoButton track={playingTrack} />
                        </div>
                      </div>
                    </>
                  )}
                  <p className="text-zinc-600 text-xs mt-1.5">
                    {tracksLoading ? "—" : `${displayedTracks.length} tracks`}
                    {playlistAuthError === "signin" && (
                      <button
                        type="button"
                        onClick={() => signIn("spotify", { callbackUrl: window.location.href })}
                        style={{ marginLeft: 8, fontSize: 11, fontWeight: 600, color: "#1db954",
                                 background: "rgba(29,185,84,0.12)", border: "1px solid rgba(29,185,84,0.30)",
                                 borderRadius: 6, padding: "2px 8px", cursor: "pointer", lineHeight: 1.5 }}>
                        Sign in with Spotify
                      </button>
                    )}
                    {playlistAuthError === "reconnect" && (
                      <button
                        type="button"
                        onClick={() => signIn("spotify", { callbackUrl: window.location.href })}
                        style={{ marginLeft: 8, fontSize: 11, fontWeight: 600, color: "#fb923c",
                                 background: "rgba(251,146,60,0.10)", border: "1px solid rgba(251,146,60,0.28)",
                                 borderRadius: 6, padding: "2px 8px", cursor: "pointer", lineHeight: 1.5 }}>
                        Reconnect Spotify
                      </button>
                    )}
                    {!playlistAuthError && playlistMsg && (
                      <span style={{ marginLeft: 8, color: "#ef4444" }}>
                        {playlistMsg}
                      </span>
                    )}
                  </p>
                </div>
                {subgenres.length > 0 && (
                  <div className="flex-shrink-0 flex gap-1.5 px-7 pb-4 overflow-x-auto" style={{ scrollbarWidth: "none" }}>
                    {subgenres.map(sub => {
                      const active = selectedSubgenre === sub.name;
                      return (
                        <button key={sub.name}
                          onClick={() => { const n = selectedSubgenre === sub.name ? null : sub.name; setSelectedSubgenre(n); selectedSubgenreRef.current = n; }}
                          className="flex-shrink-0 text-xs px-3 py-1 rounded-full whitespace-nowrap transition-all"
                          style={{ background: active ? `rgba(${sr},${sg},${sb},0.18)` : "transparent", color: active ? `rgb(${sr},${sg},${sb})` : "rgba(255,255,255,0.30)", border: `1px solid rgba(${sr},${sg},${sb},${active ? 0.45 : 0.10})` }}
                        >{sub.name}</button>
                      );
                    })}
                  </div>
                )}
                <div className="flex-shrink-0 mx-7" style={{ height: 1, background: "rgba(255,255,255,0.05)" }} />
                <div className="overflow-y-auto flex-1" style={{ scrollbarWidth: "thin", scrollbarColor: "rgba(255,255,255,0.08) transparent" }}>
                  {tracksLoading ? (
                    <p className="text-zinc-700 text-xs px-7 py-8 text-center">—</p>
                  ) : displayedTracks.length === 0 ? (
                    <p className="text-zinc-700 text-xs px-7 py-8 text-center">No tracks</p>
                  ) : (
                    <div className="flex flex-col pt-1 pb-6">
                      {visibleTrackRows.map((t, idx) => {
                        const canPlay = !!(deezerPreviews[t.id] || t.previewUrl);
                        const isPending = pendingTrackId === t.id;
                        const isActive  = nowPlayingId === t.id || isPending;
                        return (
                          <div key={t.id} className="flex items-center gap-3 px-7 py-2 cursor-pointer" style={{ borderBottom: "1px solid rgba(255,255,255,0.035)" }} onClick={() => playTrack(t)}>
                            <span style={{ flexShrink: 0, width: 20, textAlign: "center", fontSize: 11, lineHeight: 1, userSelect: "none", color: isActive ? selectedColor : "rgba(255,255,255,0.22)" }}>{idx + 1}</span>
                            <div className="flex-shrink-0" style={{ width: 36, height: 36, borderRadius: 4, overflow: "hidden", background: `rgba(${sr},${sg},${sb},0.10)` }}>
                              {t.imageUrl && <img src={t.imageUrl} alt="" width={36} height={36} loading="lazy" style={{ width: 36, height: 36, objectFit: "cover", display: "block" }} onError={e => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} />}
                            </div>
                            <div className="flex flex-col min-w-0 flex-1">
                              <div className="flex items-center gap-2 min-w-0">
                                <span className="text-sm font-medium truncate leading-snug flex-1" style={{ color: isActive ? selectedColor : "#ffffff" }}>{t.name}</span>
                                {/* Unheard dot — shown when unheard mode is on and track is unheard */}
                                {unheardMode && t.isUnheardForSelectedUser === true && (
                                  <span
                                    aria-label="Not in selected user's library"
                                    title={`Not in ${substituteProfile?.userName ?? "selected user"}'s library`}
                                    style={{ flexShrink: 0, width: 6, height: 6, borderRadius: "50%", background: selectedColor, opacity: 0.70, display: "inline-block" }}
                                  />
                                )}
                                {/* Live event ticket — always shown when artist has an event */}
                                {t.liveEvent && (
                                  <button
                                    aria-label="Open live event booking page"
                                    title={`${t.liveEvent.eventName} · ${t.liveEvent.venue}, ${t.liveEvent.city} · ${t.liveEvent.date}`}
                                    onClick={e => {
                                      e.stopPropagation();
                                      if (window.confirm("Open live event booking page?")) {
                                        window.open(t.liveEvent!.url, "_blank", "noopener,noreferrer");
                                      }
                                    }}
                                    style={{ background: "none", border: "none", padding: "2px 0", cursor: "pointer", display: "flex", alignItems: "center", flexShrink: 0, color: `rgba(${sr},${sg},${sb},0.85)` }}
                                  >
                                    <LiveEventsIcon size={12} />
                                  </button>
                                )}
                                {socialSort && tallyCount(t) > 0 && (
                                  <button
                                    aria-label={`${tallyCount(t)} other user${tallyCount(t) === 1 ? "" : "s"} have this track`}
                                    onClick={e => {
                                      e.stopPropagation();
                                      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
                                      const rawTop = rect.bottom + 6;
                                      const top = rawTop + 140 > window.innerHeight ? rect.top - 140 : rawTop;
                                      setPopoverData({
                                        trackId: t.id,
                                        users:   t.socialUsers ?? [],
                                        top:     Math.max(8, top),
                                        right:   window.innerWidth - rect.right,
                                      });
                                    }}
                                    style={{ background: "none", border: "none", padding: "2px 0", cursor: "pointer", display: "flex", alignItems: "center", flexShrink: 0 }}
                                  >
                                    <SocialBadge count={tallyCount(t)} color={`rgba(${sr},${sg},${sb},0.80)`} />
                                  </button>
                                )}
                              </div>
                              <span className="text-zinc-500 text-xs truncate">{t.artist}{isPending ? <span style={{ color: "rgba(255,255,255,0.32)", marginLeft: 4 }}>(Loading…)</span> : noPreviewTrackId === t.id ? <span style={{ color: "rgba(255,255,255,0.22)", marginLeft: 4 }}>(No Preview)</span> : null}</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
                <div className="flex-shrink-0 flex justify-end px-6 py-3" style={{ borderTop: "1px solid rgba(255,255,255,0.04)" }}>
                  <button onClick={() => { setSelected(null); setSelectedSubgenre(null); selectedSubgenreRef.current = null; setZoomSubgenre(null); zoomSubgenreRef.current = null; autoSelectedRef.current = false; if (audioRef.current) { audioRef.current.pause(); audioRef.current = null; } setNowPlayingId(null); setAudioPlaying(false); setPlayingTrack(null); }} className="text-zinc-700 hover:text-zinc-400 text-xs transition-colors">close ✕</button>
                </div>
              </>
            ) : (
              <>
                {/* ── Overview header — world name ───────────────────────────
                    Title resolves to: "Friends" | user display name | "Music"
                    Never shows "All Music" any more.                          */}
                {(() => {
                  const totalTracks = Object.values(worlds).reduce((s, c) => s + c, 0);
                  // Sublabel: context-appropriate descriptor above the title
                  const sublabel = friendsWorld
                    ? "Combined World"
                    : !userId
                      ? "Your World"
                      : null;  // individual worlds: omit sublabel, title is enough
                  // Title: the world's owner name / type
                  const title = friendsWorld
                    ? "Friends"
                    : (userName ?? "Music");
                  return (
                    <div className="flex-shrink-0 px-7 pt-6 pb-4">
                      {sublabel && (
                        <p className="text-xs tracking-widest uppercase mb-2" style={{ color: "rgba(255,255,255,0.20)" }}>{sublabel}</p>
                      )}
                      <h2 className="text-2xl font-bold text-white leading-tight">{title}</h2>
                      <p className="text-zinc-600 text-xs mt-1.5">{totalTracks.toLocaleString()} tracks</p>
                    </div>
                  );
                })()}
                <div className="flex-shrink-0 mx-7" style={{ height: 1, background: "rgba(255,255,255,0.05)" }} />
                <div className="overflow-y-auto flex-1" style={{ scrollbarWidth: "thin", scrollbarColor: "rgba(255,255,255,0.08) transparent" }}>
                  <div className="flex flex-col pt-1 pb-6">
                    {(() => {
                      const total = Object.values(worlds).reduce((s, c) => s + c, 0) || 1;
                      // Sort: primary genres by count desc, "Other" always last.
                      const sortedEntries = Object.entries(worlds).sort(([nameA, cntA], [nameB, cntB]) => {
                        const aIsOther = nameA === "Other";
                        const bIsOther = nameB === "Other";
                        if (aIsOther && !bIsOther) return 1;
                        if (!aIsOther && bIsOther) return -1;
                        return cntB - cntA;
                      });
                      return sortedEntries.map(([name, count]) => {
                        const pct   = Math.round(count / total * 100);
                        const color = COLORS[name] ?? "#71717a";
                        return (
                          <div key={name} className="flex items-center gap-4 px-7 py-2.5 cursor-pointer hover:bg-white/[0.025]" style={{ borderBottom: "1px solid rgba(255,255,255,0.035)" }} onClick={() => { autoSelectedRef.current = false; setSelected(name); }}>
                            <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: color }} />
                            <div className="flex flex-col min-w-0 flex-1">
                              <span className="text-sm font-medium truncate leading-snug" style={{ color }}>{shortLabel(name)}</span>
                              <span className="text-xs" style={{ color }}>{count.toLocaleString()} tracks · {pct}%</span>
                            </div>
                          </div>
                        );
                      });
                    })()}
                  </div>
                </div>
              </>
            )}
          </div>
        )}
      </div>

      {/* ── Mobile bottom sheet ───────────────────────────────────────────────── */}
      {isMobile && viewportH > 0 && (() => {
        const sheetH = Math.round(viewportH * 0.90);
        const snapTY = sheetSnap === 0 ? sheetH + 20 : sheetSnap === 1 ? sheetH - 260 : 0;
        return (
          <div
            onTouchStart={e => { if (mobileTracklistRef.current?.contains(e.target as Node)) return; sheetSwipeStartY.current = e.touches[0].clientY; sheetSwipeStartTime.current = Date.now(); }}
            onTouchEnd={e => {
              if (sheetSwipeStartY.current === null) return;
              const endY = e.changedTouches[0].clientY, deltaY = endY - sheetSwipeStartY.current;
              const vel  = deltaY / Math.max(Date.now() - sheetSwipeStartTime.current, 1);
              sheetSwipeStartY.current = null;
              if (vel < -0.3 || deltaY < -40) { setSheetSnap(2); return; }
              if (vel > 0.3  || deltaY > 40)  { if (sheetSnapRef.current === 2) setSheetSnap(1); return; }
            }}
            style={{ position: "fixed", bottom: 0, left: 0, right: 0, height: sheetH, zIndex: 100, display: "flex", flexDirection: "column", overflow: "hidden", background: "rgba(4,4,8,0.97)", backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)", borderTop: sheetSnap > 0 ? `1px solid rgba(${sr},${sg},${sb},0.18)` : "1px solid rgba(255,255,255,0.06)", borderTopLeftRadius: 18, borderTopRightRadius: 18, transform: `translateY(${snapTY}px)`, transition: "transform 0.36s cubic-bezier(0.32,0.72,0,1)", pointerEvents: sheetSnap === 0 ? "none" : "auto" } as React.CSSProperties}
          >
            {/* Accent line */}
            <div style={{ height: 2, background: selectedColor ?? "rgba(255,255,255,0.12)", opacity: 0.85, flexShrink: 0 }} />

            {/* ── Sheet header — left title / right button cluster ─────────── */}
            <div style={{ flexShrink: 0, padding: "12px 16px 10px", display: "flex", alignItems: "flex-start", gap: 12 }}>

              {/* LEFT — genre title + track count */}
              <div style={{ flex: 1, minWidth: 0, paddingTop: 3 }}>
                <h2 style={{ margin: "0 0 4px", fontSize: 18, fontWeight: 700, color: selectedColor, lineHeight: 1.2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {focusedSubgenre ?? (selected ? shortLabel(selected) : "")}
                </h2>
                <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                  <span style={{ fontSize: 12, color: "rgba(255,255,255,0.30)" }}>
                    {displayedTracks.length} tracks
                  </span>
                  {/* Auth errors — sign-in / reconnect CTAs */}
                  {playlistAuthError === "signin" && (
                    <button
                      type="button"
                      onClick={() => signIn("spotify", { callbackUrl: window.location.href })}
                      style={{ fontSize: 11, fontWeight: 600, color: "#1db954",
                               background: "rgba(29,185,84,0.12)", border: "1px solid rgba(29,185,84,0.30)",
                               borderRadius: 6, padding: "2px 8px", cursor: "pointer", lineHeight: 1.5 }}>
                      Sign in with Spotify
                    </button>
                  )}
                  {playlistAuthError === "reconnect" && (
                    <button
                      type="button"
                      onClick={() => signIn("spotify", { callbackUrl: window.location.href })}
                      style={{ fontSize: 11, fontWeight: 600, color: "#fb923c",
                               background: "rgba(251,146,60,0.10)", border: "1px solid rgba(251,146,60,0.28)",
                               borderRadius: 6, padding: "2px 8px", cursor: "pointer", lineHeight: 1.5 }}>
                      Reconnect Spotify
                    </button>
                  )}
                  {/* Other (non-auth) errors */}
                  {!playlistAuthError && playlistMsg && (
                    <span style={{ fontSize: 12, color: "#ef4444" }}>{playlistMsg}</span>
                  )}
                </div>
              </div>

              {/* RIGHT — compact two-row button cluster, right-aligned.
                  Every button is wrapped in a 36 × 36 circular container
                  so all five cells are identical in size and spacing.    */}
              {(() => {
                // Shared circular wrapper — matches the arrow button's own style exactly.
                const W: React.CSSProperties = {
                  flexShrink: 0, width: 36, height: 36,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  borderRadius: "50%", background: "rgba(255,255,255,0.07)",
                };
                return (
                  <div style={{ flexShrink: 0, display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8 }}>

                    {/* Row 1 (3 cells): Playlist · Spotify · Collapse */}
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <div style={W}>
                        <PlaylistButton loading={playlistLoading} success={!!(playlistKey && createdPlaylistKeys.has(playlistKey))} onClick={handlePlaylistPush} color={selectedColor} />
                      </div>
                      <div style={W}>
                        <SpotifyLogoButton track={playingTrack} size={20} />
                      </div>
                      {/* Arrow button is already a 36 × 36 circle — no extra wrapper needed */}
                      <button
                        onClick={() => setSheetSnap(sheetSnap === 1 ? 2 : 1)}
                        aria-label={sheetSnap === 1 ? "Expand to fullscreen" : "Collapse to preview"}
                        style={{ flexShrink: 0, width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center", borderRadius: "50%", background: "rgba(255,255,255,0.07)", color: "rgba(255,255,255,0.60)", fontSize: 16, lineHeight: 1 }}
                      >
                        {sheetSnap === 1 ? "↑" : "↓"}
                      </button>
                    </div>

                    {/* Row 2: [Unheard] · [Venn] · Popularity · Live Events
                        Unheard and Venn are conditional; Popularity/Live always shown.
                        Row expands left with each additional conditional button.      */}
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      {showUnheard && (
                        <div style={W}>
                          <UnheardButton active={unheardMode} onClick={() => setUnheardMode(v => !v)} color={selectedColor} name={substituteProfile?.userName} />
                        </div>
                      )}
                      {vennHref && (
                        <div style={W}>
                          <VennButton href={vennHref} color={selectedColor} disabled={!vennEnabled} onBeforeNavigate={handleVennNavigate} />
                        </div>
                      )}
                      <div style={W}>
                        <BarChartButton active={socialSort} onClick={() => setSocialSort(v => !v)} color={selectedColor} />
                      </div>
                      <div style={W}>
                        <PinButton active={liveMode} loading={liveLoading} onClick={handleLiveToggle} color={selectedColor} />
                      </div>
                    </div>

                  </div>
                );
              })()}

            </div>

            {/* Tracklist */}
            <div ref={mobileTracklistRef} className="overflow-y-auto flex-1" style={{ scrollbarWidth: "none", WebkitOverflowScrolling: "touch" } as React.CSSProperties}>
              {displayedTracks.length === 0 ? (
                <p className="text-zinc-700 text-xs px-6 py-8 text-center">No tracks</p>
              ) : (
                <div className="flex flex-col pt-1 pb-8">
                  {visibleTrackRows.map((t, idx) => {
                    const canPlay   = !!(deezerPreviews[t.id] || t.previewUrl);
                    const isPending = pendingTrackId === t.id;
                    const isActive  = nowPlayingId === t.id || isPending;
                    return (
                      <div key={t.id} className="flex items-center gap-3 px-5 py-2.5" style={{ borderBottom: "1px solid rgba(255,255,255,0.04)", cursor: "pointer" }} onClick={() => playTrack(t)}>
                        <span style={{ flexShrink: 0, width: 20, textAlign: "center", fontSize: 11, lineHeight: 1, userSelect: "none", color: isActive ? selectedColor : "rgba(255,255,255,0.22)" }}>{idx + 1}</span>
                        <div className="flex-shrink-0" style={{ width: 36, height: 36, borderRadius: 4, overflow: "hidden", background: `rgba(${sr},${sg},${sb},0.10)` }}>
                          {t.imageUrl && <img src={t.imageUrl} alt="" width={36} height={36} loading="lazy" style={{ width: 36, height: 36, objectFit: "cover", display: "block" }} onError={e => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} />}
                        </div>
                        <div className="flex flex-col min-w-0 flex-1">
                          <div className="flex items-center gap-2 min-w-0">
                            <span className="text-sm font-medium truncate leading-snug flex-1" style={{ color: isActive ? selectedColor : "#ffffff" }}>{t.name}</span>
                            {/* Unheard dot — shown when unheard mode is on and track is unheard */}
                            {unheardMode && t.isUnheardForSelectedUser === true && (
                              <span
                                aria-label="Not in selected user's library"
                                title={`Not in ${substituteProfile?.userName ?? "selected user"}'s library`}
                                style={{ flexShrink: 0, width: 6, height: 6, borderRadius: "50%", background: selectedColor, opacity: 0.70, display: "inline-block" }}
                              />
                            )}
                            {/* Live event ticket — shown in name area when liveMode is on */}
                            {t.liveEvent && (
                              <button
                                aria-label="Open live event booking page"
                                title={`${t.liveEvent.eventName} · ${t.liveEvent.venue}, ${t.liveEvent.city} · ${t.liveEvent.date}`}
                                onClick={e => {
                                  e.stopPropagation();
                                  if (window.confirm("Open live event booking page?")) {
                                    window.open(t.liveEvent!.url, "_blank", "noopener,noreferrer");
                                  }
                                }}
                                style={{ background: "none", border: "none", padding: "2px 0", cursor: "pointer", display: "flex", alignItems: "center", flexShrink: 0, color: `rgba(${sr},${sg},${sb},0.85)` }}
                              >
                                <LiveEventsIcon size={12} />
                              </button>
                            )}
                            {socialSort && tallyCount(t) > 0 && (
                              <button
                                aria-label={`${tallyCount(t)} other user${tallyCount(t) === 1 ? "" : "s"} have this track`}
                                onClick={e => {
                                  e.stopPropagation();
                                  const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
                                  const rawTop = rect.bottom + 6;
                                  const top = rawTop + 140 > window.innerHeight ? rect.top - 140 : rawTop;
                                  setPopoverData({
                                    trackId: t.id,
                                    users:   t.socialUsers ?? [],
                                    top:     Math.max(8, top),
                                    right:   window.innerWidth - rect.right,
                                  });
                                }}
                                style={{ background: "none", border: "none", padding: "2px 0", cursor: "pointer", display: "flex", alignItems: "center", flexShrink: 0 }}
                              >
                                <SocialBadge count={tallyCount(t)} color={`rgba(${sr},${sg},${sb},0.80)`} />
                              </button>
                            )}
                          </div>
                          <span className="text-zinc-500 text-xs truncate">{t.artist}{isPending ? <span style={{ color: "rgba(255,255,255,0.32)", marginLeft: 4 }}>(Loading…)</span> : noPreviewTrackId === t.id ? <span style={{ color: "rgba(255,255,255,0.22)", marginLeft: 4 }}>(No Preview)</span> : null}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        );
      })()}

      {/* ── Mobile zoom pill ──────────────────────────────────────────────────── */}
      {isMobile && selected !== null && sheetSnap !== 2 && (
        <div style={{ position: "fixed", right: 12, bottom: sheetSnap === 1 ? 276 : 84, zIndex: 120, display: "flex", flexDirection: "column", alignItems: "center", borderRadius: zoomAbove2 ? "50%" : 24, width: zoomAbove2 ? 44 : undefined, height: zoomAbove2 ? 44 : undefined, overflow: "hidden", background: "rgba(0,0,0,0.80)", border: "1px solid rgba(255,255,255,0.10)", backdropFilter: "blur(8px)", WebkitBackdropFilter: "blur(8px)", transition: "bottom 0.3s ease, border-radius 0.2s ease, width 0.2s ease, height 0.2s ease", pointerEvents: "auto" } as React.CSSProperties}>
          {!zoomAbove2 && (
            <button onPointerDown={e => e.stopPropagation()} onClick={e => { e.stopPropagation(); handleZoomPlus(); }} style={{ width: 44, height: 46, background: "none", border: "none", color: "rgba(255,255,255,0.88)", fontSize: 22, fontWeight: 300, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", lineHeight: 1, userSelect: "none" }} aria-label="Zoom in">+</button>
          )}
          {!zoomAbove2 && <div style={{ width: 24, height: 1, background: "rgba(255,255,255,0.10)" }} />}
          <button onPointerDown={e => e.stopPropagation()} onClick={e => { e.stopPropagation(); handleZoomMinus(); }} style={{ width: 44, height: zoomAbove2 ? 44 : 46, background: "none", border: "none", color: "rgba(255,255,255,0.88)", fontSize: 22, fontWeight: 300, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", lineHeight: 1, userSelect: "none" }} aria-label="Zoom out">−</button>
        </div>
      )}

      {/* ── Social tally popover ─────────────────────────────────────────────── */}
      {popoverData && (
        <>
          {/* Invisible backdrop to close on outside click */}
          <div
            onClick={() => setPopoverData(null)}
            style={{ position: "fixed", inset: 0, zIndex: 300 }}
          />
          {/* Popover card */}
          <div
            style={{
              position:        "fixed",
              top:             popoverData.top,
              right:           popoverData.right,
              zIndex:          301,
              background:      "rgba(12,12,18,0.97)",
              border:          "1px solid rgba(255,255,255,0.10)",
              borderRadius:    10,
              padding:         "10px 14px",
              minWidth:        140,
              maxWidth:        220,
              backdropFilter:  "blur(16px)",
              WebkitBackdropFilter: "blur(16px)",
              boxShadow:       "0 8px 32px rgba(0,0,0,0.55)",
            }}
          >
            <p style={{ fontSize: 10, letterSpacing: "0.08em", textTransform: "uppercase", color: "rgba(255,255,255,0.30)", marginBottom: 8, lineHeight: 1 }}>
              Also in Friends
            </p>
            {popoverData.users.length === 0 ? (
              <p style={{ fontSize: 12, color: "rgba(255,255,255,0.45)" }}>No one else</p>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {popoverData.users.map(u => (
                  <Link
                    key={u.id}
                    href={`/midvale/${u.id}`}
                    onClick={() => setPopoverData(null)}
                    style={{ fontSize: 13, fontWeight: 500, color: "rgba(255,255,255,0.88)", textDecoration: "none", display: "block", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}
                  >
                    {u.name ?? "Unknown"}
                  </Link>
                ))}
              </div>
            )}
          </div>
        </>
      )}

    </main>
  );
}
